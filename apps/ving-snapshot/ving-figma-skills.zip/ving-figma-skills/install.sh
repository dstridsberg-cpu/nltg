#!/bin/bash
# Installs the Ving → Figma skills for Claude Code (copies them to ~/.claude/skills).
set -e
here="$(cd "$(dirname "$0")" && pwd)"
dest="$HOME/.claude/skills"
mkdir -p "$dest"
for s in ving-figma-recreate ving-page-snapshot; do
  if [ -d "$dest/$s" ]; then
    mv "$dest/$s" "$dest/$s.backup-$(date +%Y%m%d-%H%M%S)"
    echo "Gammal $s sparad som backup."
  fi
  cp -R "$here/skills/$s" "$dest/$s"
  echo "Installerade $s"
done
command -v python3 >/dev/null || echo "OBS: python3 saknas. Kör: xcode-select --install"
[ -d "/Applications/Google Chrome.app" ] || [ -d "$HOME/Applications/Google Chrome.app" ] || echo "OBS: Google Chrome hittades inte."
echo "Klart. Starta om Claude Code så hittar den skillen."
