// Runs inside the live Chrome tab (via AppleScript "execute javascript").
// Returns a JSON string: { html, fields, title, url, width, height, external }.
// The html is a static clone of the rendered page with live CSS inlined.
(function () {
  var TRACKER_HOSTS = /(^|\.)(bat\.bing\.com|google-analytics\.com|googletagmanager\.com|doubleclick\.net|facebook\.com|facebook\.net|connect\.facebook\.net|analytics\.tiktok\.com|hotjar\.com|clarity\.ms|snapchat\.com|linkedin\.com|adservice\.google\.com|googleadservices\.com|pinterest\.com|criteo\.com|criteo\.net)$/i;
  var abs = function (u, base) { try { return new URL(u, base || location.href).href; } catch (e) { return u; } };
  var host = function (u) { try { return new URL(u, location.href).hostname; } catch (e) { return ''; } };
  var fixUrls = function (css, base) {
    return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g, function (m, q, u) {
      if (/^(data:|#)/.test(u)) return m;
      return 'url("' + abs(u, base) + '")';
    });
  };
  // srcset candidates are separated by a comma FOLLOWED BY WHITESPACE; URLs themselves
  // may contain bare commas (e.g. Cloudinary "c_fill,w_110,h_110"), so never split on ",".
  var fixSrcset = function (v) {
    return v.split(/,\s+/).map(function (p) { p = p.trim().split(/\s+/); p[0] = abs(p[0]); return p.join(' '); }).join(', ');
  };

  // 1. Live CSS from every stylesheet. Reading cssRules (not <style> text) is what
  //    captures CSS-in-JS (styled-components) rules injected via insertRule.
  var external = [];
  var cssParts = [];
  [].forEach.call(document.styleSheets, function (s, i) {
    var media = s.media && s.media.mediaText ? s.media.mediaText : '';
    var txt;
    try {
      txt = [].map.call(s.cssRules, function (r) { return r.cssText; }).join('\n');
      txt = fixUrls(txt, s.href || location.href);
    } catch (e) {
      // Cross-origin sheet: the Python side downloads it and substitutes this marker.
      txt = '/*@@EXTERNAL:' + s.href + '@@*/';
      external.push(s.href);
    }
    if (media && media !== 'all') txt = '@media ' + media + ' {\n' + txt + '\n}';
    cssParts.push('/* sheet ' + i + ' ' + (s.href || 'inline') + ' */\n' + txt);
  });

  // 2. Freeze form state into attributes, and record field values for PII scrubbing.
  var fields = [];
  var origFields = document.querySelectorAll('input, textarea, select');
  var clone = document.documentElement.cloneNode(true);
  var cloneFields = clone.querySelectorAll('input, textarea, select');
  for (var i = 0; i < origFields.length; i++) {
    var o = origFields[i], c = cloneFields[i];
    if (!c) continue;
    if (o.tagName === 'SELECT') {
      [].forEach.call(c.options, function (opt, j) {
        if (o.options[j] && o.options[j].selected) opt.setAttribute('selected', ''); else opt.removeAttribute('selected');
      });
    } else if (o.type === 'checkbox' || o.type === 'radio') {
      if (o.checked) c.setAttribute('checked', ''); else c.removeAttribute('checked');
    } else if (o.tagName === 'TEXTAREA') {
      c.textContent = o.value;
      if (o.value) fields.push({ type: 'textarea', name: o.name || o.id || '', autocomplete: o.autocomplete || '', value: o.value });
    } else if (o.type !== 'password' && o.type !== 'file' && o.type !== 'hidden') {
      c.setAttribute('value', o.value);
      if (o.value) fields.push({ type: o.type, name: o.name || o.id || '', autocomplete: o.autocomplete || '', value: o.value });
    }
  }

  // 3. Strip scripts, resource hints, iframes, original styles (replaced by step 1) and trackers.
  clone.querySelectorAll('script, noscript, iframe, link[rel="preload"], link[rel="modulepreload"], link[rel="prefetch"], link[rel="preconnect"], link[rel="dns-prefetch"], link[rel="stylesheet"], style, link[rel="manifest"]').forEach(function (n) { n.remove(); });

  // 4. Images: pin to what the browser actually rendered, absolute URLs.
  var origImgs = document.images;
  clone.querySelectorAll('img').forEach(function (img, k) {
    var o = origImgs[k];
    var src = (o && o.currentSrc) || img.getAttribute('src');
    if (src && TRACKER_HOSTS.test(host(src))) { img.remove(); return; }
    if (src) img.setAttribute('src', abs(src));
    img.removeAttribute('srcset');
    img.removeAttribute('sizes');
    img.removeAttribute('loading');
  });
  clone.querySelectorAll('source[srcset]').forEach(function (s) { s.setAttribute('srcset', fixSrcset(s.getAttribute('srcset'))); });
  clone.querySelectorAll('[href]').forEach(function (a) {
    var h = a.getAttribute('href');
    if (h && !/^(#|javascript:|mailto:|tel:)/.test(h)) a.setAttribute('href', abs(h));
  });
  clone.querySelectorAll('[style*="url("]').forEach(function (el) { el.setAttribute('style', fixUrls(el.getAttribute('style'))); });
  clone.querySelectorAll('use').forEach(function (u) {
    ['href', 'xlink:href'].forEach(function (at) { var v = u.getAttribute(at); if (v && v[0] !== '#') u.setAttribute(at, abs(v)); });
  });
  clone.querySelectorAll('form').forEach(function (f) { f.setAttribute('onsubmit', 'return false'); });

  var style = document.createElement('style');
  style.id = 'captured-styles';
  style.textContent = cssParts.join('\n\n');
  clone.querySelector('head').appendChild(style);

  return JSON.stringify({
    html: '<!doctype html>\n' + clone.outerHTML,
    fields: fields,
    title: document.title,
    url: location.href,
    width: window.innerWidth,
    height: document.documentElement.scrollHeight,
    external: external
  });
})();
