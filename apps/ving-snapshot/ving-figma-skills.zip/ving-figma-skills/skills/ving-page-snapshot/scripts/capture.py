#!/usr/bin/env python3
"""Capture a static, pixel-faithful local HTML copy of a page open in the user's Chrome.

Usage:
  capture.py <url-or-fragment> [--out FILE | --out-dir DIR] [--open] [--no-scroll]
             [--scrub-pii] [--inline-images] [--no-verify] [--list-tabs]

<url-or-fragment> is matched against the URLs of open Chrome tabs (exact match first,
then substring). With --open, a URL that is not open is opened in a new tab first.

macOS only: drives Chrome through AppleScript, which requires
Chrome > View > Developer > Allow JavaScript from Apple Events.
"""
import argparse
import base64
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from html import escape
from urllib.parse import urljoin, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36'
JS_DISABLED_HINT = (
    'Chrome blocks JavaScript from AppleScript. Ask the user to enable it in Chrome: '
    'View > Developer > Allow JavaScript from Apple Events (they can turn it off again afterwards).'
)


# ---------- Chrome via AppleScript ----------

def osa(script, *args):
    r = subprocess.run(['osascript', '-e', script, *args], capture_output=True, text=True)
    if r.returncode != 0:
        err = r.stderr.strip()
        if 'Allow JavaScript from Apple Events' in err or 'JavaScript through AppleScript is turned off' in err:
            sys.exit('ERROR: ' + JS_DISABLED_HINT)
        raise RuntimeError(err)
    return r.stdout.rstrip('\n')


def list_tabs():
    out = osa('''set TB to ASCII character 9
tell application "Google Chrome"
set out to ""
repeat with w in windows
repeat with t in tabs of w
set out to out & (id of w) & TB & (id of t) & TB & (URL of t) & TB & (title of t) & linefeed
end repeat
end repeat
return out
end tell''')
    tabs = []
    for line in out.splitlines():
        parts = line.split('\t')
        if len(parts) >= 3:
            tabs.append({'win': parts[0], 'tab': parts[1], 'url': parts[2], 'title': parts[3] if len(parts) > 3 else ''})
    return tabs


def find_tab(target, tabs):
    exact = [t for t in tabs if t['url'] == target]
    if exact:
        return exact[0]
    partial = [t for t in tabs if target in t['url']]
    if len(partial) > 1:
        print('NOTE: several tabs match; using the first:', file=sys.stderr)
        for t in partial:
            print('  ', t['url'], file=sys.stderr)
    return partial[0] if partial else None


def open_tab(url):
    ids = osa('''on run argv
set TB to ASCII character 9
tell application "Google Chrome"
if (count of windows) = 0 then make new window
set w to window 1
set t to make new tab at end of tabs of w with properties {URL:item 1 of argv}
return (id of w as text) & TB & (id of t as text)
end tell
end run''', url)
    win, tab = ids.split('\t')
    for _ in range(120):
        loading = osa(f'tell application "Google Chrome" to return loading of (tab id {tab} of window id {win})')
        if loading == 'false':
            break
        time.sleep(0.5)
    time.sleep(2)  # let client-side rendering settle
    return {'win': win, 'tab': tab, 'url': url, 'title': ''}


def run_js(t, js):
    with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False, encoding='utf-8') as f:
        f.write(js)
        path = f.name
    try:
        return osa('''on run argv
set js to read POSIX file (item 1 of argv) as «class utf8»
tell application "Google Chrome" to return execute (tab id ((item 3 of argv) as integer) of window id ((item 2 of argv) as integer)) javascript js
end run''', path, t['win'], t['tab'])
    finally:
        os.unlink(path)


SCROLL_START_JS = r'''(function(){
  var y0 = window.scrollY, y = 0;
  window.__vingSnap = {done:false};
  function step(){
    y += Math.max(200, window.innerHeight * 0.8);
    window.scrollTo(0, y);
    if (y < document.documentElement.scrollHeight) setTimeout(step, 150);
    else setTimeout(function(){ window.scrollTo(0, y0); window.__vingSnap.done = true; }, 800);
  }
  step();
  return 'started';
})()'''
SCROLL_DONE_JS = r'''String(!!(window.__vingSnap && window.__vingSnap.done))'''
# Lazy images in off-screen carousel slides never load in the live tab; that's fine because
# the snapshot drops loading="lazy", so they load when the copy is opened. Only wait briefly.
IMAGES_DONE_JS = r'''String([].every.call(document.images, function(i){ return i.complete; }))'''


def preload_lazy_content(t):
    """Scroll through the page so lazy-loaded images/sections render, then restore position."""
    run_js(t, SCROLL_START_JS)
    for _ in range(120):
        if run_js(t, SCROLL_DONE_JS) == 'true':
            break
        time.sleep(0.5)
    for _ in range(16):
        if run_js(t, IMAGES_DONE_JS) == 'true':
            return
        time.sleep(0.5)


# ---------- post-processing ----------

def fetch(url, binary=False):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read()
        return (data, r.headers.get_content_type()) if binary else data.decode('utf-8', 'replace')


def absolutize_css(css, base):
    def fix(m):
        u = m.group(2)
        if u.startswith(('data:', '#')):
            return m.group(0)
        return 'url("%s")' % urljoin(base, u)
    css = re.sub(r'url\(\s*([\'"]?)([^\'")]+)\1\s*\)', fix, css)
    return re.sub(r'/\*# sourceMappingURL=.*?\*/', '', css)


def inline_external_css(html, hrefs):
    for href in hrefs:
        marker = '/*@@EXTERNAL:%s@@*/' % href
        try:
            css = absolutize_css(fetch(href), href)
        except Exception as e:
            print(f'WARNING: could not download stylesheet {href}: {e}', file=sys.stderr)
            css = '@import url("%s");' % href  # fall back to loading it live
        html = html.replace(marker, css)
    return html


def placeholder_for(field):
    key = ' '.join([field.get('type', ''), field.get('name', ''), field.get('autocomplete', '')]).lower()
    if 'email' in key or '@' in field['value']:
        return 'anna.andersson@example.com'
    if 'tel' in key or 'phone' in key or 'mobil' in key:
        return '+46700000000'
    if 'given' in key or 'first' in key or 'fornamn' in key or 'förnamn' in key:
        return 'Anna'
    if 'family' in key or 'last' in key or 'efternamn' in key or 'surname' in key:
        return 'Andersson'
    if 'birth' in key or 'fodelse' in key or 'födelse' in key or 'bday' in key or field.get('type') == 'date':
        return '19900101' if field['value'].isdigit() else '1990-01-01'
    if 'postal' in key or 'zip' in key or 'postnummer' in key:
        return '12345'
    if 'address' in key or 'adress' in key or 'street' in key:
        return 'Exempelgatan 1'
    if 'city' in key or 'ort' in key or 'locality' in key:
        return 'Stockholm'
    return 'Exempel'


def fake_date_like(s):
    """A placeholder birth date in the same shape as s (850816, 19850816 or 1985-08-16)."""
    return {6: '900101', 8: '19900101', 10: '1990-01-01'}.get(len(s), '1990-01-01')


def scrub_pii(html, fields):
    """Replace values the user typed into form fields everywhere they appear in the body
    (input values and echoed text such as summary boxes). Also masks booking tokens."""
    head_end = html.find('</head>')
    head, body = (html[:head_end], html[head_end:]) if head_end != -1 else ('', html)
    replaced = []
    seen = set()
    for f in sorted(fields, key=lambda f: -len(f['value'])):
        v = f['value'].strip()
        if len(v) < 2 or v in seen or f.get('type') in ('checkbox', 'radio', 'number', 'search'):
            continue
        seen.add(v)
        ph = placeholder_for(f)
        variants = {v, escape(v, quote=True), escape(v, quote=False)}
        # Birth dates are typed as YYMMDD / YYYYMMDD but echoed as YYYY-MM-DD elsewhere.
        d = re.sub(r'\D', '', v)
        if ph.startswith('1990') and len(d) in (6, 8):
            ymd = d if len(d) == 8 else (('19' if int(d[:2]) > int(time.strftime('%y')) else '20') + d)
            variants |= {f'{ymd[:4]}-{ymd[4:6]}-{ymd[6:]}', ymd}
            if len(d) == 6:
                variants.add(d)
        hits = sum(body.count(x) for x in variants)
        if hits:
            # Longest first so "1985-08-16" isn't half-replaced via a shorter variant.
            for x in sorted(variants, key=len, reverse=True):
                body = body.replace(x, fake_date_like(x) if ph.startswith('1990') else ph)
            replaced.append({'field': f.get('name') or f.get('type'), 'placeholder': ph, 'hits': hits})
    body, n_tok = re.subn(r'(bookingToken=)[0-9a-fA-F-]{20,}', r'\1REDACTED', body)
    return head + body, replaced, n_tok


def inline_images(html):
    cache = {}

    def data_uri(url):
        if url not in cache:
            try:
                data, ctype = fetch(url, binary=True)
                ctype = ctype or mimetypes.guess_type(urlparse(url).path)[0] or 'image/png'
                cache[url] = 'data:%s;base64,%s' % (ctype, base64.b64encode(data).decode())
            except Exception as e:
                print(f'WARNING: could not inline {url}: {e}', file=sys.stderr)
                cache[url] = url
        return cache[url]

    # <source> elements would override the inlined <img>, so drop them.
    html = re.sub(r'<source\b[^>]*>', '', html)
    html = re.sub(r'(<img\b[^>]*\bsrc=")(https?://[^"]+)(")', lambda m: m.group(1) + data_uri(m.group(2).replace('&amp;', '&')) + m.group(3), html)
    return html, len(cache)


def slug_for(url):
    p = urlparse(url)
    s = re.sub(r'[^a-z0-9]+', '-', (p.path.strip('/') or 'home').lower()).strip('-')
    return s or 'page'


def unique_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    i = 2
    while os.path.exists(f'{base}-{i}{ext}'):
        i += 1
    return f'{base}-{i}{ext}'


# ---------- verification ----------

def find_chrome():
    for p in ['/Applications/Google Chrome.app', os.path.expanduser('~/Applications/Google Chrome.app')]:
        if os.path.exists(p):
            return os.path.join(p, 'Contents/MacOS/Google Chrome')
    r = subprocess.run(['mdfind', "kMDItemCFBundleIdentifier == 'com.google.Chrome'"], capture_output=True, text=True)
    for line in r.stdout.splitlines():
        if line.endswith('.app'):
            return os.path.join(line, 'Contents/MacOS/Google Chrome')
    return None


def verify(out_path, width, height):
    chrome = find_chrome()
    if not chrome:
        return {'error': 'Chrome binary not found; skipped verification'}
    work = tempfile.mkdtemp(prefix='ving-snap-verify-')
    profile = os.path.join(work, 'profile')
    shot = os.path.join(work, 'render.png')
    height = max(800, min(int(height) + 50, 16000))
    common = [chrome, '--headless=new', '--disable-gpu', f'--user-data-dir={profile}', '--hide-scrollbars',
              f'--window-size={width},{height}', '--virtual-time-budget=10000']
    subprocess.run(common + [f'--screenshot={shot}', 'file://' + out_path], capture_output=True, timeout=120)

    probe = os.path.join(work, 'probe.html')
    shutil.copy(out_path, probe)
    with open(probe, 'a', encoding='utf-8') as f:
        f.write('<script>onload=()=>{document.documentElement.setAttribute("data-broken",'
                'JSON.stringify([...document.images].filter(i=>!i.naturalWidth).map(i=>i.currentSrc||i.src)))}</script>')
    dom = subprocess.run(common + ['--dump-dom', 'file://' + probe], capture_output=True, text=True, timeout=120).stdout
    m = re.search(r'data-broken="([^"]*)"', dom)
    broken = json.loads(m.group(1).replace('&quot;', '"')) if m else None
    return {'screenshot': shot if os.path.exists(shot) else None, 'broken_images': broken}


# ---------- main ----------

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('target', nargs='?', help='URL (or part of a URL) of the open Chrome tab')
    ap.add_argument('--out', help='output .html path')
    ap.add_argument('--out-dir', default='.', help='output directory when --out is not given')
    ap.add_argument('--open', action='store_true', help='open the URL in a new tab if no tab matches')
    ap.add_argument('--no-scroll', action='store_true', help='skip scrolling the page to trigger lazy loading')
    ap.add_argument('--scrub-pii', action='store_true', help='replace typed-in personal data and booking tokens')
    ap.add_argument('--inline-images', action='store_true', help='embed <img> files as data URIs (works offline)')
    ap.add_argument('--no-verify', action='store_true', help='skip the headless render check')
    ap.add_argument('--list-tabs', action='store_true', help='print open Chrome tabs and exit')
    a = ap.parse_args()

    tabs = list_tabs()
    if a.list_tabs or not a.target:
        for t in tabs:
            print(f"{t['url']}\t{t['title']}")
        return

    t = find_tab(a.target, tabs)
    if not t:
        if a.open and a.target.startswith('http'):
            t = open_tab(a.target)
        else:
            sys.exit(f'ERROR: no open Chrome tab matches "{a.target}". Open it in Chrome or pass --open.')

    run_js(t, '1')  # fails fast with a clear message if Apple Events JS is disabled
    if not a.no_scroll:
        preload_lazy_content(t)

    with open(os.path.join(HERE, 'snapshot.js'), encoding='utf-8') as f:
        snap = json.loads(run_js(t, f.read()))

    html = inline_external_css(snap['html'], snap['external'])
    report = {'source_url': snap['url'], 'title': snap['title'], 'viewport_width': snap['width'],
              'page_height': snap['height'], 'external_css': snap['external']}

    if a.scrub_pii:
        html, replaced, n_tok = scrub_pii(html, snap['fields'])
        report['pii_replaced'] = replaced
        report['booking_tokens_redacted'] = n_tok
    else:
        report['form_fields_with_values'] = [f.get('name') or f.get('type') for f in snap['fields']]

    if a.inline_images:
        html, n = inline_images(html)
        report['images_inlined'] = n

    stamp = time.strftime('%Y-%m-%d %H:%M')
    src_url = re.sub(r'(bookingToken=)[0-9a-fA-F-]{20,}', r'\1REDACTED', snap['url']) if a.scrub_pii else snap['url']
    comment = f'<!-- Static snapshot of "{escape(snap["title"])}" captured {stamp} from {escape(src_url)} at {snap["width"]}px wide. Scripts removed; styles inlined. -->'
    html = html.replace('<head>', '<head>\n' + comment, 1) if '<head>' in html else html

    out = os.path.abspath(a.out) if a.out else unique_path(os.path.join(os.path.abspath(a.out_dir), slug_for(snap['url']) + '.html'))
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        f.write(html)
    report['output'] = out
    report['bytes'] = len(html.encode('utf-8'))

    if not a.no_verify:
        report['verify'] = verify(out, snap['width'], snap['height'])

    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
