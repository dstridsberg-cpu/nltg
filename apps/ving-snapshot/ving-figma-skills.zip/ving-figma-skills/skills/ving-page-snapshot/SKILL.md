---
name: ving-page-snapshot
description: Recreate an exact, pixel-faithful local HTML copy of a Ving / NLTG web page (ving.se, acctest/test environments, checkout, ancillaries, confirm, hotel pages, any Ving URL) from the page as it is rendered in the user's own signed-in Chrome. Use this whenever the user asks to copy, clone, recreate, snapshot, capture, save or "rebuild as HTML" a Ving page or a step in a Ving flow, wants a local baseline of a live page to redesign or prototype on, or wants several captured pages linked into a clickable flow — even if they just paste a Ving URL and say "recreate this".
---

# Ving page snapshot

Produces a single static `.html` file that looks exactly like a live Ving page: the
DOM as rendered, every CSS rule the browser applied (including CSS-in-JS), form values
as filled in, images pointing at Ving's CDN. Scripts are removed, so it's a frozen
visual baseline for design work, not a working page.

## Why it works this way

Ving pages (especially checkout) only exist inside the user's signed-in browser: a
booking token plus session cookies, and acctest returns 401 to plain HTTP. So the
capture runs *inside the user's Chrome tab* via AppleScript `execute javascript`, rather
than fetching the URL. Reading `document.styleSheets[].cssRules` (not `<style>` text) is
what catches styled-components rules injected via `insertRule`; cross-origin stylesheets
can't be read that way, so the script downloads them (Ving's asset CDNs are public).

## Workflow

1. **Locate the tab.** The user usually has the page open already. Run
   `python3 ~/.claude/skills/ving-page-snapshot/scripts/capture.py --list-tabs` if you need
   to see what's open. The capture matches the URL exactly, then by substring, so a
   distinctive fragment (e.g. `ancillaries?bookingToken=99e1`) is enough. If the page isn't
   open and is public, `--open` opens it in a new tab; for checkout/booking pages ask the
   user to navigate there themselves, since the state (booking, filled-in fields) is theirs.

2. **Decide where it goes.** Ask or infer a project folder (the user keeps projects under
   `~/Claude Code Dir/<project>/`). Name files after the flow step when it's part of a
   flow, e.g. `checkout-step-2-ancillaries.html`; otherwise the script names it from the URL path.

3. **Capture:**
   ```bash
   python3 ~/.claude/skills/ving-page-snapshot/scripts/capture.py "<url or fragment>" --out "<folder>/<name>.html"
   ```
   Options:
   - `--scrub-pii`: replaces values typed into form fields (name, email, phone, birth
     date, address) wherever they appear on the page, and redacts booking tokens. Use it
     whenever the file may be shared beyond the person who captured it. Without it, the
     report lists which fields contained values so you can warn the user.
   - `--inline-images`: embeds images as data URIs so the file works offline and survives
     CDN changes. Makes files much larger; use when asked for an offline/archival copy.
   - `--no-scroll`: by default the script scrolls the user's tab top-to-bottom (then
     back) to trigger lazy-loaded images. Mention that the tab will scroll briefly.
   - `--open`, `--no-verify`, `--out-dir DIR`.

   If it exits with the "Allow JavaScript from Apple Events" message, ask the user to
   enable **View → Developer → Allow JavaScript from Apple Events** in Chrome. Don't change
   that setting yourself. Alternatives if they'd rather not: connect Claude in Chrome, or
   have them save the page with ⌘S "Webpage, Complete".

4. **Verify before reporting.** The script prints a JSON report including
   `verify.broken_images` and `verify.screenshot` (full-page headless render). Look at the
   screenshot (downscale first, e.g. `sips -Z 2000 in.png --out small.png`) and compare it
   with what the user described. Investigate any broken images instead of shrugging them
   off. One real past bug: srcset URLs containing commas (`c_fill,w_110`) were split
   incorrectly. Note that `position: fixed` bars (the sticky price/"Fortsätt" footer)
   render at the bottom of the viewport in a tall screenshot; that's expected.

5. **Open it** for the user: `open -a "Google Chrome" "<file>"`.

6. **Report** briefly: file path, what the page contains, what doesn't work (anything
   needing JS: accordions, "Läs mer", dropdown logic, validation, buttons), whether
   personal data is present (and suggest `--scrub-pii` if the file will be shared), and
   that trackers were stripped if any were.

## Linking captured pages into a flow

When the user wants to click between captured steps (e.g. "Fortsätt" → next step,
"Tillbaka" → previous), add `onclick="location.href='<other-file>.html'"` to the existing
button elements rather than rebuilding them; that keeps the captured styling intact.
Find the buttons by their text (`>Fortsätt<`, `Tillbaka<`) and patch a unique snippet of
their opening tag; verify each patch matched exactly once. Relative file names keep the
folder portable. Leave buttons with no destination unlinked and say so.

## Limits to be upfront about

- Exact only at the viewport width it was captured at (reported as `viewport_width`).
  For mobile, have the user resize the window / use device mode before capturing.
- Frozen state: whatever was open/closed/selected at capture time.
- Images load from Ving's CDN unless `--inline-images` is used.
- `--scrub-pii` catches values typed into fields wherever they reappear verbatim (plus
  birth dates reformatted as YYYY-MM-DD). Details shown on the page that were never in
  a form field, e.g. pre-filled from a logged-in profile, are not caught: search the
  output for the user's name/email if it matters.
- macOS + Google Chrome only (AppleScript).
