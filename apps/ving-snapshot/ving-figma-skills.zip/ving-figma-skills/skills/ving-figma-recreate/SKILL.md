---
name: ving-figma-recreate
description: Rebuild a Ving / NLTG web page (a captured HTML snapshot or a Ving URL; checkout, booking, hotel and content pages) as an editable Figma design that uses ONLY the NLTG design system, i.e. components from "NLTG Website | Component library", variables and styles from "Design Token", icons from the NLTG icon library, and reports what the design system is missing. Use this whenever the user wants a Ving page "in Figma", "recreated/rebuilt in Figma", "as a Figma page for prototyping", "with our components/tokens", or wants a design-system gap analysis of a live page, even if they only paste a URL or a snapshot file and say "Figma".
---

# Ving page → Figma (design system only)

Input: a static snapshot of the page (from the `ving-page-snapshot` skill or the Ving Snapshot
bookmarklet), or a URL you capture first. Output: a frame in a working Figma file that recreates
the page from library instances and token-bound frames, plus a gap report the DS team can act on.

The point isn't a pixel copy (the HTML snapshot already is one). The point is a page designers
can keep editing with real components, and an honest list of where the DS falls short. When the
DS lacks something, build it from tokens and log it. Don't fake it with a look-alike.

## Hard rules
- **Never modify the two library files** (`TBykMSk5Zw3c3wniZjioht` Design Token,
  `bVsa27MoHkKt5dOVl4WjQf` Component library). Read and import only. Build in a working file.
- **Tokens only**: every colour, spacing, radius, stroke and type value is bound to a Design Token
  variable or a text/effect style. Fixed widths and image sizes are the only raw numbers.
- Load `figma:figma-use` and `figma:figma-generate-design` before the first `use_figma` call and
  pass `skillNames: "figma-use,figma-generate-design"`.
- Never place a screenshot of the page (or a whole section) in the design. Screenshots are reference.
- **Clip content off**: set `clipsContent = false` on every frame and component you create (it is on
  by default and cuts off shadows). Keep it only on image containers. See gotchas.md.
- **Checkout pages** also use the published library "Checkout - Local Components"
  (`G7vGI33aPgwyJLYb1uP6Ly`). Decided 2026-10-29: everything specific to checkout lives there,
  not in Ving's main library. Prefer its components (stepper, ancillary card, traveller row,
  flight leg header, selectable tile, radio card, hotel/flight summary, price table, summary bar)
  over building from tokens. Get the keys with a read-only `use_figma` on that file. New
  checkout-only gaps go to the DS owner first, and get built there only after they approve.

## References (read as needed)
- `references/component-map.md`: Ving web signatures → DS component, known gaps G01–G14. **Read first.**
- `references/components.md`: library inventory: keys, variants, properties, status.
- `references/tokens.md`: semantic variables and styles with keys and Ving-light values.
- `references/gotchas.md`: fonts that can't load, slots, images, component quirks. **Read before building.**
- `references/library-inventory.md`: read-only scripts to refresh the inventory when keys fail.

## Workflow

### 1. Get the snapshot
If you have a URL rather than a file, capture it with the `ving-page-snapshot` skill (or ask the user
to use the Ving Snapshot bookmarklet), with personal data scrubbed unless they say otherwise.

### 2. Analyse it
```bash
python3 ~/.claude/skills/ving-figma-recreate/scripts/analyze_snapshot.py <snapshot.html> --out <project>/figma-build/<page-slug>
```
It renders at 1440 px (Ving's desktop design width) and writes `outline.md` (structure with Ving
component names, boxes, styles, text), `page.png`, `section-NN.png` crops, `sections.json`, and the
page's content images in `images/` with `images.json`. Read `outline.md` and look at the
section crops. That's your source of truth for content and layout. Use `--width 390` for mobile.

### 3. Plan the build (short, in your head or a `plan.md` next to the outline)
For each section in `sections.json`: the web signature, the DS component (from component-map.md,
then components.md, then `search_design_system` scoped to the two libraries plus the icon library),
variant/props, and whether it's a gap. Reuse instances. Where a pattern repeats without a DS
component (meal tiles, traveller rows), build **one local component** in the working file and
place instances of it.

### 4. Prepare the target
- Target: the file the user names, or ask. Steps of the same flow go side by side on one page
  (200 px apart, in flow order) so they read as a flow. Unrelated pages get their own page.
- **Look for earlier rebuilds in the file first** (read-only `get_metadata` on the page). If one
  exists for the same flow, `clone()` it and keep the shared shell (header, stepper, sticky bar,
  section headings) and the patterns you need (add-on card, traveller row, collapsed Accordion
  item, Button with Source Sans label) as templates. Clones keep the font overrides that make
  library text editable, so this sidesteps most of the brand-font problem. Never edit the
  earlier rebuild itself. Remove what the new page doesn't have.
- `create_session` with the target fileKey, then reuse the sessionId everywhere.
- Check font availability once:
  `(await figma.listAvailableFontsAsync()).some(f => f.fontName.family === 'Thomas Headline')`.
  If it's true, the font workarounds in gotchas.md aren't needed: apply the real text styles.
- `get_libraries` on the target file: the two NLTG libraries and the icon library should be
  added. If they aren't, tell the user (adding libraries is their call).

### 5. Build
Follow figma-generate-design: wrapper frame first (1440 wide, fill `surface/page/primary`,
vertical auto-layout), then sections built straight inside it, top to bottom, in retry-safe
batches (a few sections per call). Set `placeholder = true` on a section until it's filled.
Import components with the keys from components.md, and variables/styles with keys from tokens.md
(`Promise.all` the imports at the top of each script). Fill SLOTs by appending into the slot frame.
Use the swap workaround for instances containing brand-font text. Return all created IDs.

### 6. Images
Create image frames at the captured sizes, then `upload_assets` with `nodeIds` = those frames and
POST each file from `images/` (see images.json for which image goes where). For image layers
inside library instances, use the temp-rectangle + imageHash copy described in gotchas.md.

### 7. Check
- One screenshot of the wrapper (`get_screenshot`, maxDimension 2000). Compare with `page.png`
  section by section: missing content, wrong order, clipped text, wrong variants, placeholder text.
  One targeted fix pass, one more screenshot, then stop.
- Run `scripts/audit_tokens.js` (replace FRAME_ID) through use_figma and fix every raw value it
  reports on your own frames. Report the final count.

### 8. Report and learn
Tell the user, briefly:
- the Figma link to the frame (`https://www.figma.com/design/<fileKey>/?node-id=<id with - instead of :>`)
- which sections use DS components, and which are token-built
- the gap list: reuse G-numbers from component-map.md, add new ones (G15…) for new gaps,
  one line each: what the page needs, what you used instead, suggestion
- text waiting for brand fonts (`Apply style → …` layers), if the fonts weren't available
- the token audit result

**Gap report artifact:** always build it from `references/report-template.html`. Copy the
template, replace `REPORT_TITLE` (2–4 words, e.g. "Min sida DS-luckor") and `REPORT_DATA` with a
JSON object `{kicker, title, lead, links, empty, items}`: kicker = page name, title = "Hur gick
det?", lead starts with a `<strong>` phrase, links = `[{label:"Visa sidan i Figma", url}]`, and
one item per gap `{id, label, status, kind, title, result, html, comments}`. New gaps get
status "wait"; put fonts, coverage table and other background in status "info" (column "Läs mig
först"). Don't change the template's look: it's the agreed design language (minimal,
Polestar-inspired, Source Sans Pro, Ving palette). Write everything in Swedish, in plain spoken
language. Publish it as an artifact and give the user the link.
Then **update `references/component-map.md`** with any new web signatures, mappings, and gaps,
so the next rebuild is faster and more consistent. This is how the tool improves.
