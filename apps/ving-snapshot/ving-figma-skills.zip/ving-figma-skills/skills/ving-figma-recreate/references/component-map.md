# Component map: Ving web → NLTG Figma design system

How to read a captured page: `analyze_snapshot.py` lists each element's component names taken from
Ving's class names (styled-components display names such as `Button`, `Link`, `Gridstyle__Grid`;
BEM classes such as `webui-sticky`, `checkout-extra-per-pax-multi`; CSS modules as `css:<name>`).
Match those names here first, then fall back to visual judgement.

**This file grows.** After every rebuild, add new web signatures you met, what you used, and any
new gap (next free G-number). Keep entries short. Last updated 2026-10-29 (Min sida added; rebuilt by clone on DEMO page 175:7571).

Status: ✅ DS component fits · 🟡 DS component with workaround · 🔴 no DS component (token-built frame, logged as a gap)

## Page frame (all checkout steps)
| Web signature | Figma | Status |
|---|---|---|
| `body` bg #faf6f1 | Wrapper frame, 1440 wide, fill `surface/page/primary` | ✅ |
| `Gridstyle__Grid` / `Grid__StyledGrid` content column 1224 wide at x=108 | Auto-layout column, 1224 fixed width (no width tokens exist, a known exception), page side padding via `layout/page-margin` is NOT 108, so center the column instead | ✅ |
| `header` white, bottom border 3px #fe8c00, `header-logotype` | **G02**: token frame: fill `surface/card/primary`, bottom stroke `surface/brand` × `dividers/fat`, `nltg` (Ving logotype) instance | 🔴 |
| Step indicator: `ol` of `uikit-font-button` numbered circles (teal #2e696c), labels "Resa / Uppgifter / Tillval / Bekräfta" | **G01**: `progressbar` Steps=4, Progress=<current>. Its Step labels props are NOT wired in the 4-step variant: set the text layers directly | 🟡 |
| `h2.uikit-font-section-heading` (Thomas Headline 32) e.g. "Boka tillval" | Text, size `heading/headline/section`, layer name `Apply style → headline/heading/section-headline-xl` | ✅ (font, see gotchas) |
| `webui-sticky` fixed dark bar: hotel picture 110×110, name, geography, `Rating` waves, specification, Totalpris, `Button` "Fortsätt", back link "Tillbaka" | **G10**: token frame fill `surface/footer/primary`, text `elements/text/static/inverse`, `Wave rating`, `Button` primary, `Link` back (renders as a dark pill, there's no light variant) | 🔴 |
| Hotel thumbnail in sticky (`webui-sticky-hotel__picture`) | Frame 110×110 radius `components/textinput` (4) with uploaded image fill | ✅ |

## Step "Uppgifter" (traveller and contact details)
| Web signature | Figma | Status |
|---|---|---|
| Text inputs (filled, valid ✓) | `Text field` State=default, Validation=success, Filled=true | ✅ |
| Disabled input (lead traveller email copy) | `Text field` State=disabled | ✅ |
| Phone with country select | `Phone field` | ✅ |
| `select` (country, Välj) | `Droplist` Filled true/false | ✅ |
| Gender radios | `Radio button` (inside a row; `Radio group` if a label is needed) | ✅ |
| Small inline link "(Yngre än 18 år?)" with external icon | `Link` Variant=text + hide arrow, icon `UI_link_external` | 🟡 |
| Wheelchair assistance link with icon | `Link` text + `MISC_WHEELCHAIR` | ✅ |

## Step "Tillval" / add-ons (also the add-on section of "Uppgifter")
| Web signature | Figma | Status |
|---|---|---|
| `li.extra-group-container` white card, radius 8, pad 24, shadow | **G03**: token card: fill `surface/card/primary`, radius `card/default`, padding `padding/m`, effect `elevation/base`; inside it `Cards/Base` Image=left, Image width=4 col, Show background=false for the image+text row | 🔴 (outer) / 🟡 (inner) |
| `webui-image-block--ancillary` / `css:headerContainerTop`: image 392×236 left + title (Thomas 28) + text + "Total kostnad" | `Cards/Base` (left, 4 col): put `Card content/Headline` + `Card content/Text` in its Content slot; image fill on its image layer | 🟡 |
| `h3.webui-image-block__content-header-title` (Thomas 28, #505050) | `Card content/Headline` or text sized `heading/headline/card`, colour `elements/text/static/tertiary` | ✅ |
| `p.co-group-header__html` body text #505050 | `body/default` style, colour `elements/text/static/tertiary` | ✅ |
| "Från 375:-/vuxen" (Thomas 18) | text `heading/subheadline/card-subheadline`, Apply style → headline/subheading/subheadline-s | ✅ |
| `webui-ancillary-option__price` / `css:totalPrice` "Total kostnad 0:-" (Thomas 19 bold, #505050), right-aligned | Text `Apply style → headline/subheading/subheadline-s-bold`, colour `elements/text/static/tertiary` | ✅ |
| `Link` + `IconAfter` chevron "Läs mer ⌄" | `Link` Variant=expandable | ✅ |
| `checkout-extra-per-pax-multi` / `-per-group-optional` / `-per-pax-and-period`: grey row (#f7f7f7, pad 16) with bold label and a round chevron button | **G13**: `Accordion item` Expanded=false (closest), or token row fill `surface/card/tertiary` + `UI_chevron_down`. Prefer Accordion item when the row expands | 🟡 |
| `webui-ancillary-expanded__item` with flight leg text + `Button` "Välj avresa/hemresa" (seat reservation) | **G14**: token row fill `surface/card/tertiary`, padding `padding/default`, `body/default-bold` route + `body/default` time, `Button` primary on the right | 🔴 |
| Traveller row: name + select (`checkout-extra-per-pax-*` expanded) | **G04**: token row `surface/card/tertiary`, radius `card/list-item`, `Droplist` without label | 🔴 |
| Flight leg bar "Utresa … Sunclass Airlines" | **G05**: token bar `surface/card/tertiary` + `TRAVEL_AIRPLANE` | 🔴 |
| Meal tiles (image, name, price, Läs mer, radio) | **G06**: local component built once from tokens + `Radio button` + `Link` | 🔴 |
| Transfer option cards with radio | **G07**: local component, tokens + `Radio button` | 🔴 |
| Excursion list (many grey rows with chevron) | Stack of `Accordion item` Expanded=false (or G13 rows) | 🟡 |
| `ancillaries-panel` "Prisdetaljer" collapsed panel (Thomas 24 + chevron) | `Accordion item` Expanded=false in a token card; or `prisdetaljer-checkout` when expanded | 🟡 |
| Built 2026-10-21 for step 3 (lab file node 96:6470): seat rows = clone of the G04 traveller row with the Droplist swapped for a `Button` primary cloned from the sticky bar (label editable); add-on rows and the 15 excursions = `Accordion item` Expanded=false with `Headline` set via setProperties (works on clones); "Total kostnad" under the row for Specialbagage (web puts it at the card bottom) | | |
| Save the Children add-on (logo image) | Same add-on card pattern (G03) | 🔴/🟡 |

## Step "Bekräfta" (confirm) and "Din resa" summary
| Web signature | Figma | Status |
|---|---|---|
| Hotel card with image, name, area, waves, facts | `Cards/Booking` Layout=image left (image is 4 col, web is 6 col: **G11**; hide payment column and extra rows by hand) | 🟡 |
| Flight summary: CHARTERFLYG tag, outbound/return columns | **G08**: token-built; tag `[Umbraco] tag` Type=Info (closest olive) | 🔴 |
| Price table | `prisdetaljer-checkout` (fixed 3 traveller columns × 11 rows: **G12**, hide extras) or `prisdetaljer` Number of rows=3/6/8/10 (more configurable, try first) | 🟡 |
| "Öppet köp" olive banner | **G09**: `status-success` desktop-one-line (looks different), or token frame `states/info/surface/default` + `states/info/text/default` | 🟡 |
| Discount code input + "ANVÄND" | `Text field` + `Button` secondary | ✅ |
| Terms checkboxes with links | `Checkbox` + `Link` | ✅ |
| "Bekräfta din bokning" primary + "Tillbaka" | `Button` primary + `Link` back | ✅ |

## Content page "Min sida" (logged-in start page), built 2026-10-29 (lab file node 168:7148)
| Web signature | Figma | Status |
|---|---|---|
| Site `header` with `header-main-nav` (Resor/Hotell/Sista minuten, name, heart, search) | `navigation-desktop.header` **scroll=yes** (scroll=no loses MIN SIDA, heart and search when instanced: **G15**). No logged-in state with the user's name: **G16** | 🟡 |
| `logout-panel`: "Hej Daniel, roligt att se dig!" (Wave Serif 36) + `Button` "Logga ut" (outline) | **G19**: token row; text sized `heading/headline/page`, `Apply style → headline/heading/page-headline-l`; `Button` secondary with label font overridden | 🔴/🟡 |
| `load-booking-link` / `PushWrapper` white 608×77 info cards (16 bold, chevron; 2nd card without chevron) | `[Umbraco] push` desktop; set its inner frame `full.with.push` to FILL (fixed 392 inside: **G17**), hide the chevron by hand | 🟡 |
| `tpl-advanced-push` image 392×248 + headline + chevron | `[Umbraco] advanced push / desktop` w. subtext=no, chevron=yes (exact 392×318); hide the `[Umbraco] tape` layer; image hash into layer `Img` | ✅ |
| `tpl-push` 392×70 white link card (Thomas 19 bold + chevron) in `tpl-push-grid` | `[Umbraco] push` desktop (392×72) in a wrapping auto-layout row, gap/counter gap `layout/gutter` | ✅ |
| `tpl-section-heading` h2 (Thomas 32) + preamble (Thomas 19) with underlined inline link | **G20**: text sized `heading/headline/section` / `body/preamble`, underline by range | 🔴 |
| `footer` dark, 4 columns, newsletter, payment logos, bottom links | `footer [ignore_autid]` desktop.footer, Show footer image=false, FILL to 1440. Content differs from live: **G18** | 🟡 |
| Re-run 2026-10-29 16:04 snapshot: cloned 168:7148 to page DEMO (175:7571), only greeting text changed ("Hej Daniel Robin, …"). Clone route took 4 calls, audit 0. Live footer now: "Få nyhetsbrev med unika förmåner" + orange send button, payments Swish/Resurs/Presentkort/Trustly/Visa/Mastercard, underlined links, © 2026 (G18). No chat button in this snapshot. `listAvailableFontsAsync` match on "Wave" hits "Wavefont" (false positive): test for "NLTG Wave Serif" exactly | | |
| Floating chat button (orange circle, bottom right) | not built: **G21** (`COMMUNICATION_CHAT_CONVERSATION` icon exists, no FAB component) | 🔴 |

## Known gaps (report these in the gap list of every rebuild that hits them)
G01 numbered checkout stepper missing; `progressbar` 4-step labels not wired (bug) ·
G02 checkout header (logo only) missing · G03 add-on card with full-width rows under the image ·
G04 per-traveller selection row · G05 flight leg info bar · G06 selectable product tile ·
G07 radio card · G08 flight summary variant of flight.details · G09 olive info banner vs status-success ·
G10 checkout sticky summary bar + light Link variant for dark backgrounds · G11 Cards/Booking image
width / payment column options · G12 prisdetaljer-checkout column/row options ·
G13 grey expandable add-on row (Accordion item is close but not the same look) ·
G14 seat-reservation flight row with button ·
G15 `navigation-desktop.header` scroll=no drops MIN SIDA/heart/search in instances (bug; scroll=yes works but lacks the orange bottom line) ·
G16 header has no logged-in state (user name instead of MIN SIDA) · G17 `[Umbraco] push` inner frame fixed 392 (doesn't stretch to 6 col), no "hide chevron" toggle ·
G18 footer content out of date vs live (newsletter heading/button, payment methods, link lists, copyright year, chevrons vs underlined links), default width 1730 ·
G19 My page greeting + logout panel · G20 section heading with preamble · G21 floating chat button.
Minor: `Link` text always shows an arrow (hide by hand); `Link` arrow variant is a dark pill;
Text field has one width only; no width tokens (content column 1224, image sizes are raw numbers).
