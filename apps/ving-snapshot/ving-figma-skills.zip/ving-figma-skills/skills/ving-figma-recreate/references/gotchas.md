# Gotchas (learned the hard way)

## Library files are read-only
`TBykMSk5Zw3c3wniZjioht` (Design Token) and `bVsa27MoHkKt5dOVl4WjQf` (Component library):
read and import only. Never run a use_figma script against these keys that calls a setter,
`create*`, `remove`, `appendChild`, `setProperties`, writes a description, or adds Code Connect.
Build in a working file. If the user names no file, ask, or use their lab file
`HO0yA4mbSq9EbkJ8wWuzk4` (Lab (Daniel) test w. Claude Code) on a new page.

## Brand fonts can't load in use_figma
Thomas Headline and NLTG Wave Serif aren't org-shared fonts, so the server-side plugin runtime
can't load them. Effects:
- Applying `headline/*`, `body/preamble`, `component/button|tag|tape|tabs|card-header`, `display/*`
  text styles to your own text throws "unloaded font".
- `appendChild` / `insertChild` / `setProperties` on an instance that contains such text throws too.
  Common offenders: `Button`, `[Umbraco] tag`, `progressbar` labels, `Accordion item` headline,
  `Card content/Headline`, `Cards/*`, `Wave rating` (has text), `prisdetaljer*`.
**Workaround for placing instances:** create an instance of a text-free component (an icon, e.g. `UI_chevron_right`
05c1148c973d0aa4b5338fa1987e9200a05fbdeb; the old `Favorite` key no longer imports) inside the target parent, then
`inst.swapComponent(targetVariant)`. Swapping doesn't need the font loaded. **Editable text (found 2026-10-29):** after loading Source Sans Pro, you CAN set
`textNode.fontName = {family:'Source Sans Pro', style:'Bold'}` on a brand-font text layer inside an instance, then
set `characters`. Rename the layer `Apply style → <style>`. This works for Button labels, push headlines, etc.
Otherwise text in those instances can't be changed by script. Leave the default text where it's acceptable, or list it under
"apply by hand".
**For your own headings:** Source Sans Pro, `fontSize` bound to the matching size token
(`heading/headline/section` etc.), weight bound to `primitive/font/weight/*`, family bound to
`primitive/font/family/body`, and name the layer `Apply style → <style name>` so a designer can apply
the real style later in one pass. Once an admin shares the fonts org-wide, this goes away: test with
`figma.listAvailableFontsAsync()` for "Thomas Headline" at the start of each run.

Usable text styles: body/default, body/default-bold, body/body-text-s, body/body-text-s-bold,
body/body-text-xs, component/link, component/tooltip.

## Tokens only (user rule)
Every fill, stroke colour, stroke weight, radius, gap, padding, font size/weight/family must be bound
to a Design Token variable (see tokens.md). No hex, no loose px. Exceptions that have no token:
fixed widths (wrapper 1440, content column 1224, image boxes) and heights of image frames.
`figma.createAutoLayout()` adds an unbound white fill, so set `fills = []` on structural frames.
Run the audit script (SKILL.md step 7) before reporting.

## Colour matching from the web page
Match captured hex to the nearest semantic token by role, not by exact hex:
#505050 text → `elements/text/static/tertiary`; #202020 → `elements/text/primary`;
#f7f7f7 grey rows → `surface/card/tertiary` (#f0f1f2); #2e696c teal stepper has no semantic
token: use the DS `progressbar` as is. Note colour mismatches in the gap report only if they're
visibly different in role.

## Slots
`Cards/Base`, `Accordion item`, `Accordion`, `Droplist`, `Radio group`, `modal`, `textblock`, `Tabs`,
`Carousel` expose SLOT properties. Find the slot frame inside the instance (a child FRAME whose
name matches the slot property, e.g. "Content") and `appendChild` into it. You can append into a
SLOT but not into any other part of an instance.

## Images
use_figma can't fetch URLs. Use `upload_assets` with `nodeIds` pointing at frames/rectangles
you created (count = number of images, POST each file to its URL, e.g.
`curl -X POST -F "file=@img-01.jpg;type=image/jpeg" <submitUrl>`). Each POST response contains the
`imageHash`. Image layers inside library instances (e.g. the `image` frame in Cards/Base) can't
be upload targets: upload to temporary rectangles, then set
`{type:'IMAGE', imageHash, scaleMode:'FILL'}` on the instance's image layer (cloned fills array)
and delete the rectangles. The analyser already converts AVIF to JPEG. Don't upload a screenshot of the whole page as a design layer. Screenshots are
reference only.

## Component quirks
- Some swapped instances lose children vs their main component (seen: `navigation-desktop.header` scroll=no). Compare
  `findAll().length` of instance and variant; if they differ, try the other variant.
- Upload loops in zsh: `set -- $p` doesn't word-split. Run one curl per upload and check the HTTP status.
- `Link` Variant=text always shows a trailing arrow icon: hide the icon layer when the web has none.
- `Link` Variant=arrow renders as a dark pill: use Variant=text for orange "Läs mer >" links.
- `progressbar` Steps=4: Step N label props don't update the text, so edit the text layers directly
  (needs font: they use Source Sans, so this works).
- `prisdetaljer-checkout` always has 3 traveller columns and 11 rows: hide the extra layers.
- `Cards/Booking` image is always 4 col, and payment/Tripadvisor parts have no toggles: hide layers.
- `status-success` one-line clips long text: set the text layer's `textTruncation = 'DISABLED'`.
- Text props on library instances have `#id` suffixes: read `instance.componentProperties` keys
  before `setProperties`. Nested building blocks (`.button.primary`, `.settings link.parent`) hold
  the text props of Button and Link.
- Pages: `await figma.setCurrentPageAsync(page)` once per call. Context resets every call.
- Return value limit is 48 KB. Return IDs and counts, not full trees.

## Clip content is on by default: turn it off
`figma.createFrame()` and `figma.createComponent()` start with `clipsContent = true`. That cuts off
drop shadows (elevation styles on cards, buttons) and anything that sticks out, and designers then
have to hunt for it. Set `clipsContent = false` on every frame and component you create.
Keep it on only where cropping is the point: image containers (image, logo, media, photo) and
rounded frames whose children must follow the corner. Before reporting, check your frames:
`frame.findAll(n => 'clipsContent' in n && n.clipsContent && n.type !== 'INSTANCE')` should only list
those image containers.
