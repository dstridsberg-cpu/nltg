# Refreshing the library inventory (read-only)

Run these when an import key fails, a component behaves unlike components.md, or the
user says the library changed. They only read: no setters, no create/remove/append. Running them
against the library files is allowed. Changing anything there is not.

## Component pages
Get page ids with `get_metadata` (fileKey `bVsa27MoHkKt5dOVl4WjQf`, no nodeId). Then one
use_figma call per page, all in parallel in one message:

```js
const page = await figma.getNodeByIdAsync("PAGE_ID");
await figma.setCurrentPageAsync(page);
const list = page.findAllWithCriteria({ types: ['COMPONENT_SET','COMPONENT'] })
  .filter(n => (n.type === 'COMPONENT_SET' || n.parent.type !== 'COMPONENT_SET') && !/^[._]/.test(n.name));
return { page: page.name, items: list.map(n => { const props = {};
  try { for (const [k,v] of Object.entries(n.componentPropertyDefinitions))
    props[k] = v.type === 'VARIANT' ? v.variantOptions.join('|') : v.type; } catch(e) {}
  return { name: n.name, t: n.type === 'COMPONENT_SET' ? 'set' : 'comp', key: n.key,
           desc: (n.description||'').slice(0,320), props }; }) };
```

## Variables (Design Token file `TBykMSk5Zw3c3wniZjioht`)
Return values are capped at 48 KB, so query one collection at a time. Collection ids:
color `VariableCollectionId:7390:19`, spacing `VariableCollectionId:9652:7646`,
font `VariableCollectionId:9481:1054`, border-radius `VariableCollectionId:4074:193`,
stroke `VariableCollectionId:9946:2282`, elevation `VariableCollectionId:5241:63`.

```js
const c = await figma.variables.getVariableCollectionByIdAsync("COLLECTION_ID");
const mode = c.modes[0].modeId; const out = [];
for (const id of c.variableIds) {
  const v = await figma.variables.getVariableByIdAsync(id);
  if (!v || v.hiddenFromPublishing || !v.name.startsWith('semantic/')) continue;
  let val = v.valuesByMode[mode], d = 5;
  while (val && val.type === 'VARIABLE_ALIAS' && d-- > 0) {
    const a = await figma.variables.getVariableByIdAsync(val.id);
    val = a.valuesByMode[mode] ?? Object.values(a.valuesByMode)[0]; }
  out.push([v.name.replace('semantic/',''), v.key, typeof val === 'object' ? JSON.stringify(val) : val]);
}
return out;
```
Update tokens.md / components.md with what changed, and add the date.
