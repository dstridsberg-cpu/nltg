# NLTG Website | Component library: inventory

Source file `bVsa27MoHkKt5dOVl4WjQf` (READ-ONLY, never write to it). Inventoried 2026-10-21.
Import sets with `figma.importComponentSetByKeyAsync(key)`, single components with
`figma.importComponentByKeyAsync(key)`. Property names below omit the `#id` suffix: read the
real keys from `instance.componentProperties` before calling `setProperties`.

Status lives in each description: **trial** = current (maps to the @nltg/ui React kit),
**legacy** = avoid. Names starting with `.` or `_` are private building blocks. Never place them
directly, except as the nested parts a public component already contains.

## Actions
| Component | Key | Type | Props | Use |
|---|---|---|---|---|
| Button | 6b6495f0c1a14e89e6c172795d8fed4defa4e58f | set | Variant: primary, secondary, ghost, tertiary, secondary-light, secondary-dark | Main buttons. Label sits on the nested `.button.*` instance (`Label text`). |
| Link | 85f23b78003de51990f34bca4e5d41fa72482749 | set | Variant: text, arrow, back, expandable | Text links. Nested `.settings link.parent` has Text, show icon left/right. |
| button-open-images | f8e19aa55abfadbe27c27bf27cd82b0c72edfae2 | set | open-image: large, small | Gallery button on images. |

## Forms
| Component | Key | Props |
|---|---|---|
| Text field | 78236edba144ced05da3246785905ebcdf61ac41 | State (default/hover/focus/disabled), Validation (none/error/success), Filled, Label, Show label, Placeholder, Value, Message, Show message |
| Phone field | 2d9eeea2f2a12f0195d741adf3fb1565ddc3f0af | as Text field + Country code |
| Droplist | c1bf4d6bba5600afb701867e6e230340fb58b864 | State, Filled, Open, Label, Show label, Placeholder, Value, Show icon, Icon, Message, Options (SLOT) |
| Droplist option | fa22966fd23ec9b59882944ebf2befc824b11fd1 | State (default/hover/selected), Label, Show icon, Icon |
| Checkbox | e9c2fc5c542c4dab3060fc6d09da5ff27f84cd71 | Checked, State, Error, Label, Show label, Message, Show message |
| Checkbox group | 9b032535e519ad8c6cb34ebaff6b77304c1bc223 | Validation, Options (SLOT), Label, Message |
| Radio button | 4d15be56d44d93b0b5058762515876af0bccac22 | Checked, State (default/hover/disabled), Label, Show label |
| Radio group | cbb250adc3a575d559c1a2ac9a4e8948085b2153 | Validation, Options (SLOT), Label, Message |
| Toggle | ead8eb362d3abbaeb83335a2e080ae3ceab13ae8 | Checked, State, Label |
| Slider | a207cf59e99f4c3ec45f7c3d88807ab76032b7cd | Type (single/range), State, Label, Value text, Min, Max |
| date.picker.desktop | bb958b7073bc2c72a0428eaff7681ed22b90f222 | State |
| filter / filterActive / filterActiveDroplist | eefdc562d13149778de54d53579b2fb447c95416 / cfe9b93271fc96c09a5e11692346530274c69e3e / eb7d72f18d8b2e9e59852f6070007c4a211c6950 | Filter chips |

## Cards (slot-based; content goes into SLOT children via appendChild)
| Component | Key | Props | Use |
|---|---|---|---|
| Cards/Base | 28eeddb74e048c47dc5bb38a4a55d65fcd40ab72 | Device (desktop/mobile), Image (top/left/right/none), Image width (4 col/6 col), Show background, Show tags, Show aside; SLOTs: Content, Image overlay, Tags, Aside | Generic image + content card. Content slot holds `Card content/*` blocks. |
| Cards/Hotel | e6cd187b70e53cad35b1d04fda843777b1d5c9d7 | Device, Layout (image top/left), Show concept row | Hotel lists |
| Cards/Booking | 854a064819d8ec0c3e7ddfd85e7040bf8cd9404e | Device, Layout (image top/left) | Booked trip summary ("Din resa") |
| Cards/Room | aed3d62ab3b9102fde22c2fba28a29b13a078c4a | Device, Image (top/none), Selection (select/sold out) | Room/cabin choice |
| Cards/Article | 7cd7740f98edd333c8de8b4904f01544d15fec07 | Device, Layout | Inspiration |
| Cards/Combination | 7c9868f98372f7b59e69f2369b4fc957b105bb8b | Device, Layout | Multi-hotel packages |
| Cards/Cruise | d80dfdc67add4c8ae9774031874d63130a6f4eed | Device, Layout | Cruises |
| Card content/Headline | 8e0311600e48a0c12137c9c24bd68b7bbd7c312a | comp | Block for the Cards/Base Content slot |
| Card content/Text | eabfdf8fa381bf5e57cf700773e6a406e7c44014 | comp | Block for the Content slot |
| Card content/Rating | f42ea120e03f2b9acbf5f70f0a41afb9a2a495df | comp | Block for the Content slot |

## Booking flow and modules
| Component | Key | Props | Use |
|---|---|---|---|
| progressbar | 00f20548ab12c230597280f77923809c84f9ca0b | Steps (3/4/5), Progress, Step 1–5 label | Checkout step indicator (closest match, see map G01) |
| stepper | ff4603ea30940d6beda23698ceace0e48cb2c0e8 | Steps, Current | Dot stepper, no labels |
| prisdetaljer-checkout | eb249e92958c612875c1227d21ec7ac7b6a48d12 | Property 1: desktop.prisdetaljer. / mobile.prisdetaljer. | Checkout price table |
| prisdetaljer | da227f833c1afaeafbf9ca2216c8f905698fb448 | Number of rows (3/6/8/10), header/row/total TEXT props | Generic price table, more configurable |
| flight.details.desktop | bea015ad16049d8c89fa9f2e4ac2814f7924ceb2 | Property 1: Välj flyg (2)/(3), Ändra flyg (2), 2 stop, 3 stop | Flight choice (search results, not summaries) |
| flight.details | e44538b92f294fe5dc65a9b2d46c7e57b6acad36 | many booleans | Flight offer row |
| booking.start | 4030d52a3eb9d6ad76d23bc0b1763f443498cd31 | Property 1 | Search box |
| Accordion | 739dedbb16f24e31d8d982aa057369b50ee97e3d | Device; Items (SLOT) | Expandable list |
| Accordion item | 7003a450bb030b3256c4bb342f149dc63092bb2c | Breakpoint, Expanded, Media (none/icon/image), Headline, Sub info, Meta, Icon; Content (SLOT) | One row; put custom content in Content slot |
| List | e29bebfb08b4f6869cf08cbda06b02e0c93f194a | Marker (bullet/number/icon/check), Direction, Item 1–10 | Bullet lists, KSPs |
| Link grid / Link item | e9c9a2d28b46a63d8ce152adae65ade254f74bdb / 99589ad885d2afe303b37e7bcf045a47e7abfbd4 | | Link columns |
| textblock | 1afd2ffd947a7f3f29f67b17f57c9018ba879960 | Breakpoint, Right column; Content (SLOT) | Editorial text |
| modal | 54e3863e96743cf00f5a43cf3d91f3f22ff94b25 | Layout (desktop-l/mobile), Footer; Content (SLOT) | Modals / bottom drawers |
| Tabs | 663c1027a2845380ef926ae760c1e0805d921e67 | Type (underline/button/highlighted), Width; Tabs (SLOT) | Tabs (others on that page are legacy) |
| Carousel / Push card / Push card simple | 7d935c1681d341c0cfccb268672d5b444a7fd2b9 / 04e1e61da536f73d5c0ac2ee53f8ca302e095b18 / 456731a2b37161632f61c48a5165c48975547b0a | | Content carousels |

## Status and labels
| Component | Key | Props |
|---|---|---|
| status-information | 094276fd1a0130f134ecab278be66f652b7d7743 | device, notification (desktop-one-line/closed/expanded, mobile-*), Headline, Text, Show / Hide info |
| status-success | 8842c53ff6e3582066ab2d64c0d04216f8522a7c | same |
| status-notification | 35b38747cb34b2492733a63594f4437bdbea0d75 | same |
| status-error | 54456201b0039547ff9ad78ff18e059185f6ad37 | same |
| desktop.system.notification | bfb92cb0105b1d8f6954d7024a1c0e5aaddd84dc | Feedback |
| Inits | 2760daeb7b106578f3e3798ac72019be64ec761e | Property 1 (information/line.support/notification/tertiary .init), Text |
| [Umbraco] tag | 29d16e728f9d1f2f2aa3b359696360fae58826d7 | Type (Default/Info/KSP/Success/Alert/Error/Sale), Size (s/m), Uppercase, Label, icons |
| tag | 683a1171bbebeead6a6e06d0b066f122303825c3 | Versaler, Label, icons (older; prefer [Umbraco] tag) |
| [Umbraco] tape | 2d196305dc6135fe70ff9e1fb06b272dcc09d72c | Tape (Single/Double) |
| tooltip | 0f935694e0ae9c7887571eee42a45e305058de05 | Direction, text |
| Urgency.push | 4859326b2d8f7fee42c76a71b45308f886cb0ae1 | Text |

## Brand assets and ratings
| Component | Key | Notes |
|---|---|---|
| nltg (logotypes) | 39bafac1d84b05080810ad94665feb65dca159d5 | NLTG logotypes = Ving logotype, Spies, Tjäreborg… |
| ving.wave | b3401f83f63cb5b2b99a954b2c7687bc3c44cbb5 | |
| Wave rating | 0b5ca4582236cc2bd8d8da6d9e104c3ee3c540dd | booleans 1–5, + |
| Rating | 50593596ad8a7ff61687bc01dc4f94210424f050 | Wave + Tripadvisor + GuestRating |
| GuestRating / Tripadvisor | 4d368ad1b10630019c8f9ae94c995dd992a0ba22 / 069184cd7a1b277ec5b1db057ef1b201661d4f35 | |
| ConceptLogo / ConceptBadge | 09616be1d7eff19a2944b1ea6fb27a7edbdcf5fb / 201be1ac3b2a7bfcb4fd0b0bb8489165a1a3d56c | Sunwing, Sunprime, OBC, Family Garden |
| Favorite | d67057352c46f8b1ce0a5608890532873fb258ce | heart; text-free (useful for the font swap workaround) |

## Navigation and heroes
| Component | Key | Notes |
|---|---|---|
| navigation-desktop.header | efcc652c0c25d2ba67acb3eea8664205746e0778 | Full site header (not checkout, see G02) |
| navigation-mobile.header | 4538c751c658af6be81d1be43770339560168049 | |
| footer [ignore_autid] | 97eb36a7274553bab611db8fa0429ebaeccca215 | mobile/desktop.footer |
| Breadcrumbs | 0f245e228ef5bfc82f10250b57fe8a918f413ced | |
| image-hero / image-page-hero / image-hotell-hero | aea61f9b7b8973fe2ba2098b72b30fdfecedcc78 / db6f7f3794d577987820ab13bec30625962ee7c8 / 94d7e7f645cd8d84c90605f8fb541cb3e23a666e | |

## Icons (separate library: "Icon – NLTG UI Library")
Icons aren't in the component library file. Find them with `search_design_system`
(entity component, e.g. "chevron down", "airplane"). Keys already used successfully:
```
UI_chevron_down            5bdcd55fb89f4703cb58097980d1442d5c0967a1
UI_chevron_up              296898e55e9e21387fa0defc7caf64210e2689ff
USER_INTERFACE_ARROW_04_DOWN 34185a277b877214815121012b868decd79308db
USER_INTERFACE_ARROW_04_LEFT de6c13a85b7ada8f033b10429d0ba2381194e01d
USER_INTERFACE_ARROW_03_LEFT 1c10bf6ba5a117d4fdd077a3a36a948dd70acb17
UI_link_external           80d127e731e13241c97163c8dbcebf5ac268ceaa
UI_notification_off        326b76bdd99a2074eb504a278bf50f70bbbe9f2d
UI_user                    cfd1c094adbc011db91d5e4d416fabc4615026e2
MISC_SUCCESS               ea9e1e7ca78e6a3cba5d984824552af8ed768c71
MISC_WHEELCHAIR            9551ccbdc8cffb286243e046c7b5297fa1570832
TRAVEL_AIRPLANE            695f0b427bd10d4b44e89226698bf4c2f9fac930
Travel_airplane            1a1933bfb20be589c12c27be47b71ad59e225f91
Travel_baggage             0736c52904a3bda484faceda8360d1ae88b33b7a
Time_location_calendar     122e285b25b6f43a22eabd311a8970800df13f2d
TIME_LOCATION_BED          69401329548c2fcfe5887f84a4afa9e761ba95ee
FOOD_BEVERAGE_RESTAURANT   aaa28f124690b1ee86f8d6032e5b4cf7f39658c8
```

## Not inventoried in detail
Umbraco push pages (advanced push, bubbies, budget push, fullwidth push, push, simple push,
text push), maps, carousel internals. Search with `search_design_system` when a page needs them.
