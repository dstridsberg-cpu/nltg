# Design Token library: semantic variables

Source: **Design Token** file `TBykMSk5Zw3c3wniZjioht` (READ-ONLY, never write to it).
Inventoried 2026-10-21. Import with `figma.variables.importVariableByKeyAsync(key)`.
Values are for mode *ving light* (colour) / *ving desktop* (spacing, font) / *ving* (radius, stroke).
If a key fails to import, the library changed: re-inventory with the read-only script in
`library-inventory.md`.

Format: `name · key · value`. All names are prefixed `semantic/` in Figma.

## Spacing (collection `spacing`, modes ving desktop/mobile/app, globetrotter ×3)

Use `layout/*` between page-level blocks, `content/*` inside a card/section, `padding/*` for insets.

```
layout/related        21a3358ccf995e75b51e529a488b0e05b61918ec  8
layout/semi-related   833f508b835d62be5e625416410dae717f707918  24
layout/section        0116bfe284d0df043d2bf8aa0ed0d83afe4e45fe  60
layout/section-padding f109b45433217a5573c8b18e6e825bc5a6083b7b 60
layout/page-margin    20a15c9e6975754106e2ba44a07bdf931d0be9c1  24
layout/gutter         8e9c333b5fa25f88bd831e5c00165fde7c15769c  24
layout/page-end       ba8487d9a8d4a335f631d0030e5a21316a6c0177  80
content/tight         d82bdec7bbea7962d11931181695b6e1471be3fc  2
content/field         00e3c99dfdb7c3ae29a4f52e051951b728234ce3  4
content/item          3b57584292466c49596b666c421d20e02f87bf8a  8
content/attached      3bba4f95329d4a919009797ad0d005a7acaac99e  12
content/block         34225a3b85a2616481da14043aa29f298c7e73ff  16
content/section       0019162c1df517ee33e8836434509d932c170c48  24
content/group         fa2d0d8bd33e7619c52ccb3d3b3a9aca472fd9e2  48
padding/3xs           25acfef30f083d514500f26ed5c26e6a422b5da9  2
padding/2xs           06869e6c70b62f1a8f820b08a72a5967b41f943f  4
padding/xs            3a1072b9033393e3369bf1c6cbbf781f22c4eee5  8
padding/s             4a206dab9cadd61a2539ff9b0ed6ab09be414a02  12
padding/default       94f265c55f3c5ee7f9171d5433037c5bf59cc877  16
padding/m             20ee5a75644dc30bdd834b3e71763bc4d055aac6  24
padding/l             b5babc8ad0faaad8b472dfeb7c41c86ac39db3f4  32
padding/xl            54fe6109ac83e7924f03976a5970eba79397d452  48
```

## Radius (collection `border-radius`, modes ving/globetrotter)

```
card/default           b501044814ae838f6b6d3ba40f4c8fbdf94ef36d  8
card/list              ad315d8c149f6cfe6f8ccf759d5bd7c439467082  8
card/list-item         c3dd924cabeb3cdc936daa70816c7d77938a3968  4
card/pop-up            c7ee851b661793c5468502620e6e24fb333051e0  8
card/bottom-drawer     f8e642de594992c1915b0cc51fab7c6c6b4b0b02  16
states/info            561758bf150159ba9d17ccaabe6131e8655f5437  8
states/push            7513aa627a76eb387ebe459911a258ec4bf4db27  8
states/urgency         c26a9678d5abaafda1584d5b98720ea41c65b973  2
states/hotel-label     a80196d494a33d3b91dd69aa5c1b3fa03ec27d42  8
components/button      14f70be6e840c71e859d592abed5e95b10a30637  9999
components/textinput   feab5ba09ead919037097dee1e5338a3152d9a6a  4
components/select      be3bdee4ff4ff6423d8fc9fe33b98e939c52a48b  4
components/checkbox    32de8977c019cee273b2e1f493205fa170a4615e  4
components/radiobutton 77f6fe7645deea68a087ee2753d8120b48ce8c66  9999
components/tag         84e695687bc739c36dccb2d0573b62b8567a4de2  4
components/tape        f99c2ae7892a412305a8d05df8f2e3570dcfe8f5  4
components/tooltip     13cdfb275618f6f3f044e19945718c7bc3f38809  4
components/tabs        c64fa68326b45dfdd819f07edde4766bf7920144  9999
components/inits       511d565d60be82422758fecd60f20136847edf7c  4
components/price/tile  a01cdb194d4e3839c669e8080ea57d778662c639  2
components/link/graphical db7e8693e7bde1b7e5ab8074d6c196091a2662fb 9999
```

## Stroke weight (collection `stroke`)

```
borders/default        bfb9477e3334e58a8e5a9b48f39cee12a1d9af1a  1
borders/bold           e49e7c28436ed7e71633aead8b9525a165891a5e  2
borders/focus          dca59ad1539436a59b4c93db240ccb3a28bad2dc  2
dividers/default       708a9544a5e5ed80e22ce4efa20c3e1159ee2595  1
dividers/bold          8f76b98330e0fa33bacca16cce9ec14cae112c18  2
dividers/fat           c49a69b478db56e0a9f1cb2a0feceef0cf0e2f59  3
components/card/selected 4a9488bdaba28fc91ccff9ea5c4073c6bf1abfb2 2
components/card/focus  9cdc5945c3ee17393ef7557716f67cc7233bee8f  2
components/message/default 31103a66080944bc369bd04941c8e845bd1a9b26 2
components/textinput/default e179576dededd52a739839c86655f04be45346fb 1
components/tabs/selected b5c79f2b9f210ddda9e56d523bcab2a99ec90830 3
```

## Font (collection `font`, modes ving desktop/mobile/app, globetrotter ×3)

Families: `primitive/font/family/body` 02850c99c3c97d530c9b132ce683ffdda463a548 (Source Sans Pro),
`primitive/font/family/headline` d9ba1f754e0395aa135ce34c60baaeb1c4022b97 (Thomas Headline),
`primitive/font/family/serif` d9c044e107acb5470de35ab7d098e5204e69508a (NLTG Wave Serif).
Weights: `primitive/font/weight/regular` 2b4908d49b0d6943e8aadf7efb044848a4019269 (400),
`primitive/font/weight/bold` 6c37859f0e894b786020507ba1509fc09ff91426 (700).

```
display/default                    c487c15378fda7c1e168dc7e280a7d09eb1d102f  72
display/push/fullwith              863d7a264658742bca7003a55567d313532bcb9e  40
heading/headline/page              8e062864a77d85dd50fd0b6c4e6517fb2a314800  36
heading/headline/section           dcfc92c40ded66074853451b97712db34f3082f5  32
heading/headline/card              8e5fbbde4d19f17f694668b6587a64db32c8a803  26
heading/headline/price-large       616845e45e2f99806b7c460e3d99dd842c386372  34
heading/subheadline/card-subheadline 12ad6f02a99457703b8ddb0ed036dc9fade4a914 19
heading/subheadline/card-paragraph 8d99350c279b2672fa28c7ef4f7009be86f8495c  16
heading/subheadline/card-mini      c771b59a3472eedc20f82d42ef4d5c847cabdcfd  12
heading/over-line/eyebrow          5b989e9a0297a4e7e2225e6a8529422c9ea049f0  16
body/preamble                      9d1f62c2b6bdbf9633d37c8e04d5945f41f8baaa  19
body/default                       36aa79c83e4d5c49e797648bb4276de766375dc1  16
body/s                             d574cf7ff0f8dc6f2e36283aed71f5d1370784f5  14
body/xs                            014dd865a14508553afbc0e3a66c4c1eef09d846  12
components/button/label            b1a32a943eb9bdf5cd8b5b6098a172739c183ca1  19
components/link/label              87c6ae1840f26b4c60931442f04775b4b2e6ceac  16
components/tag/label               fd2c611ccbf0e3ad79df851fa54cb14b788b49ba  14
components/tabs/label              4dd3a5c13804fca71b48d6b1ac1bb9a245f59511  16
components/navigation/label        8395b80f3481fa5257fb473563a07a4091c7419f  19
```

## Text styles (import with `figma.importStyleByKeyAsync(key)`)

Usable from use_figma (Source Sans Pro, loads server-side):
```
body/default            f0c8f3a82c3d35737a51113a3f4908ee7fc1c450  16 Regular
body/default-bold       85e704c02b5d2e402500bb7c7f5d363cf475eaa3  16 Bold
body/body-text-s        0177309f8872ca99041797159ba2988eb8a6cd14  14 Regular
body/body-text-s-bold   6971e4b5626ba4008b394e0ffb20ab8ea4a4ff08  14 Bold
body/body-text-xs       68d32444d3fbbfa8d54a7f9003b0c295451d1a86  12 Regular
component/link          7182b0dd30a1a85fdf2776fb9a3b599ee7ec3c6e  16 Regular
component/tooltip       2f37812a989ab9a5169aeed38ccf714ec30d3cee  14 Regular
```
NOT loadable from use_figma (Thomas Headline / NLTG Wave Serif, see gotchas.md). Name the layer
`Apply style → <style>` and use Source Sans Pro bound to the size token instead:
```
headline/heading/page-headline-l        be3acd36a2307eafb573275829091de8f5d724b1  Wave Serif 36
headline/heading/section-headline-xl    f1124c596b7e091f6a0e9a3e4f3ce6f8aec900eb  32
headline/heading/section-headline-xl-bold fc50faf2a19a38c1ce13a6f3244640bad29da705 32 Bold
headline/heading/card-headline-m        0bb0f3ce4b682adfedb0c9f5646fc9ab4236a397  26
headline/heading/card-headline-m-bold   4d3bc12892ca7de68a57e7d463efee32488edac7  26 Bold
headline/heading/price                  8cf29c63effbece0b726a197e414cafb9440f44e  26 Bold
headline/heading/price-l                3019ef1e9961c11dcc8772a49e3267e4743223cd  34
headline/heading/price-l-bold           b3bcaa05724279e29bf29294ce13d6b274f3ddef  34 Bold
headline/subheading/subheadline-s       7e050ae77aec646ef1929febd5b61f351e87fe9b  19
headline/subheading/subheadline-s-bold  ac5d7fc92d3553c1b2e499cbfd9658f480f8b2c8  19 Bold
headline/subheading/subheadline-xs      948ce6e184f468793d1fa65c7c0a1167e59666db  16
headline/subheading/subheadline-xs-bold 3bbb71c1a9d8022c2ddf26b32cbf3dff9f385027  16 Bold
headline/overLine/eyebrow-xs            f0aaa9c5dc99c787a28feabd239bef7e24fb07c3  16
headline/overLine/mini(-bold|-bold-caps) 8852dac9a03ec4228b576bb2a2b372ac7388712d / c6a8f6d18ec1e911984dfd9fc51f954b05877270 / 19f04ac6c491ea15e521977425cfd635e059dc36  12
body/preamble                           f2b84a6dc4b7acf3f57bd4479e264b9e7b7780ec  19
component/layout/card-header            d0836ae1bbd6d98764a4c0abe94d29c388f3ccc8  16 Bold
component/button/button                 6f0f4d7bc19a03a96741ce55d5ae42b4e441d597  19 Bold
component/tag                           9c1cdac9a7d4251a1d57c58d559932ab14182502  14
display/mega                            2ad909013b64fa024bd2edcd3811b04f157a7e15  Wave Serif 72
```

## Effect styles

```
elevation/base          c7ea91ced8453872d2418952a2794f4224017ff8
elevation/raised        ffb0e8ac36a96d360e1d49f68185ef01e874be36
elevation/floating      e22aa4e7b469f6dbdb6e0b6cd9bfeced63e90b8f
elevation/overlay       6f218b3e602b3b07ba433fd42331ecde8a505061
elevation/notification  ad79dd57737f369c26fdf92d5f2f6ce536b35a06
elevation/sheet         f26b68ea863ff37e2a998a1ffbfc122e19fa5175
```

## Colour (collection `color`, modes ving/globetrotter × light/dark/app). Ving light hex shown

Use the hex to match captured page colours to a token; never paint the hex itself.

Surfaces
```
surface/page/primary        4b141a36fb84da0ab3d0e35bc2bc26e2afef26d4  #faf6f1  page background
surface/card/primary        2ade1e6944be5fc851e89a2387fdfb2aca526e3d  #ffffff  cards
surface/card/secondary      17477ba40c88e25b8ddfef3ae01be93c31973528  #eee1d2
surface/card/tertiary       13a56f70040b3ee0aed9b254fc9983c452c1e2cb  #f0f1f2  grey rows inside cards
surface/card/quaternary     540b8628c169f1c24c9e2b8ee47886463fccd549  #d6d6d6
surface/brand               ae9f14e2b04c413e4a0c5c15f8122d8dfaf40b84  #fe8c00  orange header line
surface/variant             af87c6f66a73c70660f936452256c1b77ef051de  #fff496
surface/accent/primary      3ba566b9c2ebaa50113359a38996cc42690726e2  #a1ab87  olive
surface/footer/primary      b3113424f7d72f73cd7720a8b40a9da5fe0e4b09  #5e5e5e  dark sticky footer
surface/overlay/primary     05774aa65586947b449748b8af5a505009cbc03b  #202020@80
surface/on/image            102b78796c06ae1852f3db2ba3972b22db21e23d  #ffffff
surface/static/primary      23525698b7cc96306e37118bb10d4e354004a138  #ffffff
```
Text and icons
```
elements/text/primary       48068fe2c43e73ba66a6ce6f5f53485893e81447  #202020
elements/text/secondary     50afea02519db4a3587ea10af128b944a6bf8a1c  #5e5e5e
elements/text/inverse       190c4b064aed30e2aff10568b83f1dc3397cade0  #ffffff
elements/text/disabled      4e6ed79c2f249126187c843eb3c183d2eacc2684  #8f8f8f
elements/text/sale          600c1b2bc345b55c8b04cd73f9900b5d772067fe  #c44800
elements/text/success       d236b1daaa021c605306eb77eb02442ebba389fb  #14663c
elements/text/on/brand      f7da78616531635e2d0294bf4aca8733841e2803  #ffffff
elements/text/on/accent     81173df196e2d6df75e53cd11d892eddc6712bb3  #202020
elements/text/static/primary c27fde8834c514f408588dbf6d20684d4ac8ef68 #202020
elements/text/static/secondary ecafb818c6080dfb9317833f2015eb9d50b1a4dd #5e5e5e
elements/text/static/tertiary 5fc00fbe5228c5a069d5bcadc7892f33d5ee5d37 #505050
elements/text/static/inverse fd891b41af6a41fc047fd9f6a5d2ce677557dc0c #ffffff
elements/icon/surface/primary   b136e05242ca0b811e745bda4a662adb02cd6e9c  #202020
elements/icon/surface/secondary d69a441f86732cec448a8345989e48bea9ed9c97  #737373
elements/icon/surface/inverted  93fa21d49552edada5c1cd72c32c3e8fc5863bdd  #ffffff
elements/icon/surface/brand     d85e90ac406246bead0a173cdedae8acf5ceb291  #ff5e00
elements/icon/surface/success   6109ff037dd13e6a722a73a95c75b232a335f268  #14663c
elements/icon/surface/error     e0d474c84157e11b8f09d550e977b93e857dd388  #c9372c
elements/icon/surface/inactive  87c3e09e0631d2a62a6b4af5637e43e4c00347a2  #8f8f8f
elements/stroke/divider     b8f91864628794b6b93e84c64ddb57d866c2594e  #c6c6c6
elements/stroke/key-line    ad98b39d8f8b974695435b587f090674008d26dd  #c6c6c6
elements/focus/ring         2eda83bac06b15844e88f3e889ab00a521cbb975  #202020
```
Components (most used in checkout)
```
components/button/primary/surface/default   0c5264154fb21275bffda57baab0029e9c550f51  #ff5e00
components/button/secondary/border/default  0323de4530965a7bc5697dbf8658b267e6164878  #ff5e00
components/button/secondary/text/default    5f95738f6234a4b9da6464d82c316c67ff95639a  #ff5e00
components/link/primary/default             94747018c20ec9b25c040f95b884822190cb84a8  #c44800
components/link/secondary/default           161c73e211a3be14d4c41827e7d7e0dec2cd52cd  #202020
components/link/static/default              83ada3dd7cf1e9d929a6a6ac8ea28a3f9130bf4d  #c44800
components/textinput/surface/default        8b8ea9b38e0f93a9ad6d2532943209826cbd4f34  #ffffff
components/textinput/border/primary         6e4dc6f52eb56ad0de0cfbf59e491b52d228b241  #8f8f8f
components/textinput/border/success         b9c888db56a7042979000b11c4fa291d83c27929  #14663c
components/card/border/selected             251f8aa244212ddeae487884d2d09de34f99353b  #c44800
components/tag/surface/default              a904a5900ab60036f11cea946dd25ed1eafe0950  #202020
components/tag/surface/info                 9862bfd629b359b81320972690e1f5cff87fe650  #cdd5b5
components/tag/surface/ksp                  1b018df58cdeed4d6abef7a20a91cf6eeda2b286  #eee1d2
components/tag/surface/success              acfc4f490fdc97fecd7cf034329012a96d57f20c  #14663c
components/tag/surface/sale                 923a1c6dc2cba8a090224ff8541ff5d592021aa8  #ff5a52
components/price/text/sale                  850e2cc724bf613aba5eb02d68780a7a321b2657  #d44942
components/filter/surface/selected          c6175628cbfd1273560f5647bafe5455cc97e3a8  #ffebd6
components/inits/surface/information        4f32c8bffea1bfc8a093f89c224ed70975c78c22  #202020
```
States
```
states/info/surface/default      5db43d7d696100adbe938728a763a8a357b97892  #d9e0c7  olive info box
states/info/text/default         7f09429308e5d65823565bbcbdad5284bef87fb9  #052409
states/info/border/default       86a42ad20d16fd7c9de22d3883e74bc251ea8b5e  #052409
states/system/surface/success    4b90109dbb411d347e6592fa714eea18be87627b  #f4fbf8
states/system/surface/alert      a148ecd34183eaaf7eb12e30b0e2b6a404fd53dd  #fff8de
states/system/surface/error      b3da6785cbd0cac3b7d704dec45ff011daaf91d5  #ffffff
states/system/text/success       a7ad6e66696d3fe78cdd146d7fb0e2cf26c6ed07  #14663c
states/system/text/alert         0e00c327a57321134519ab4529105e17cf5a98b7  #8b2e16
states/system/text/error         7b6a11939571b38e9eecc4224b0578ccc7be112c  #8b2e16
states/system/border/success     39cc7bb626347ffe27270327d6932f56f839f721  #14663c
states/system/border/alert       2bf0ba8ac6a52c980f336b439cdada5262418e36  #d07000
states/system/border/error       3f93282f52242ee74c9b353163dfce2ffbc0ad56  #c9372c
states/sale/primary              620a510fe7f75a13b04350a6b85cfdf1350fbad9  #ff5a52
states/campaign/primary          26f2068d12fb2f42e5262fab9d9a389726323b78  #ff5a52
states/push/urgency/surface/primary 57a81d54bf407b0b6df1185516d4c2aa381a1f87 #a5d5d8
```
The full colour list (≈190 semantic tokens, incl. tape, tabs, map, filter, switch, ghost/tertiary
buttons, campaign and brand/hotel colours) can be re-read with the inventory script.
