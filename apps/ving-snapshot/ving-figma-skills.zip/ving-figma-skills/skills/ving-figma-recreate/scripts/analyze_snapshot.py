#!/usr/bin/env python3
"""Turn a captured Ving page (static HTML snapshot) into build input for Figma.

Usage:
  analyze_snapshot.py <snapshot.html> --out <dir> [--width 1440] [--no-images]

Writes to <dir>:
  outline.md       indented, readable page structure: component names (from Ving's class
                   names), boxes, key styles and text. Read this first.
  outline.json     the same tree as data
  sections.json    top-level page blocks with y ranges, plus a crop PNG for each
  page.png         full-page render at --width (the visual reference)
  section-NN.png   crops of page.png per section (downscaled to max 1600 px wide)
  images/          every distinct content image, downloaded, named img-NN.<ext>
  images.json      [{file, src, w, h, x, y, alt}] in page order, for upload_assets

Needs Google Chrome (headless) and macOS `sips`.
"""
import argparse
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request

UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36'

PROBE_JS = r'''
(function () {
  function sigOf(el) {
    var out = [];
    (el.getAttribute('class') || '').split(/\s+/).forEach(function (c) {
      var m = c.match(/^([A-Za-z][A-Za-z0-9]*(?:__[A-Za-z0-9]+)?)-sc-[a-z0-9]+-\d+$/);   /* styled-components displayName */
      if (m) { out.push(m[1]); return; }
      m = c.match(/^styles_([A-Za-z0-9]+)__[A-Za-z0-9_-]{4,}$/);                       /* CSS modules */
      if (m) { out.push('css:' + m[1]); return; }
      if (/^[a-z][a-z0-9]*(-[a-z0-9]+)+(__[a-z0-9-]+)?(--[a-z0-9-]+)?$/.test(c) && !/^(is|has|js)-/.test(c)) out.push(c); /* BEM */
    });
    return out;
  }
  function ownText(el) {
    var t = '';
    el.childNodes.forEach(function (n) { if (n.nodeType === 3) t += n.textContent; });
    return t.replace(/\s+/g, ' ').trim();
  }
  function rgb2hex(c) {
    var m = c && c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!m) return null;
    if (m[4] !== undefined && +m[4] === 0) return null;
    var h = '#' + [m[1], m[2], m[3]].map(function (v) { return (+v).toString(16).padStart(2, '0'); }).join('');
    return m[4] !== undefined && +m[4] < 1 ? h + '@' + Math.round(m[4] * 100) : h;
  }
  var SEMANTIC = /^(HEADER|MAIN|SECTION|FOOTER|NAV|ASIDE|ARTICLE|H1|H2|H3|H4|H5|BUTTON|A|INPUT|SELECT|TEXTAREA|LABEL|IMG|SVG|P|UL|OL|LI|TABLE|TR|TD|TH|FORM|FIELDSET|PICTURE)$/;
  var images = [];
  function walk(el, depth) {
    var cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return null;
    var r = el.getBoundingClientRect();
    /* zero-size wrappers can still hold absolutely positioned content (e.g. <picture> around an img) */
    var zeroSize = (r.width < 1 || r.height < 1) && cs.position !== 'fixed' && el.tagName !== 'BODY';
    if (r.width <= 1 && r.height <= 1 && el.children.length === 0 && el.tagName !== 'BODY') return null; /* visually-hidden a11y text */
    var node = {
      tag: el.tagName.toLowerCase(),
      sig: sigOf(el),
      box: [Math.round(r.left + scrollX), Math.round(r.top + scrollY), Math.round(r.width), Math.round(r.height)],
      text: ownText(el).slice(0, 600)
    };
    var st = {};
    var bg = rgb2hex(cs.backgroundColor); if (bg) st.bg = bg;
    if (node.text) { st.color = rgb2hex(cs.color); st.fs = parseFloat(cs.fontSize); st.fw = cs.fontWeight; st.ff = cs.fontFamily.split(',')[0].replace(/["']/g, ''); }
    if (parseFloat(cs.borderTopWidth) > 0 && cs.borderTopStyle !== 'none') st.border = cs.borderTopWidth + ' ' + rgb2hex(cs.borderTopColor);
    else if (parseFloat(cs.borderBottomWidth) > 0 && cs.borderBottomStyle !== 'none') st.borderBottom = cs.borderBottomWidth + ' ' + rgb2hex(cs.borderBottomColor);
    if (parseFloat(cs.borderTopLeftRadius) > 0) st.radius = parseFloat(cs.borderTopLeftRadius);
    if (cs.boxShadow && cs.boxShadow !== 'none') st.shadow = 1;
    if (/flex|grid/.test(cs.display)) { st.layout = cs.display + (cs.flexDirection === 'column' ? ' col' : ''); var g = parseFloat(cs.rowGap || cs.gap) || parseFloat(cs.columnGap); if (g) st.gap = g; }
    var pad = [cs.paddingTop, cs.paddingRight, cs.paddingBottom, cs.paddingLeft].map(parseFloat);
    if (pad.some(function (p) { return p > 0; })) st.pad = pad;
    if (cs.position === 'fixed' || cs.position === 'sticky') st.pos = cs.position;
    if (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') {
      node.input = { type: el.type, value: el.value, checked: el.checked, placeholder: el.placeholder || '' };
    }
    if (el.tagName === 'IMG' && el.currentSrc) {
      node.img = el.currentSrc; node.alt = el.alt || '';
      images.push({ src: el.currentSrc, alt: el.alt || '', box: node.box });
    }
    var bgi = cs.backgroundImage && cs.backgroundImage.match(/url\("?([^")]+)"?\)/);
    if (bgi && r.width > 40 && r.height > 40) { node.bgImg = bgi[1]; images.push({ src: bgi[1], alt: '', box: node.box, background: true }); }
    if (el.tagName === 'svg') { node.svg = el.outerHTML.length < 4000 ? el.outerHTML : '(large svg)'; node.children = []; }
    else {
      node.children = [];
      for (var i = 0; i < el.children.length; i++) { var c = walk(el.children[i], depth + 1); if (c) node.children.push(c); }
    }
    if (zeroSize && !node.children.length) return null;
    if (zeroSize) node.text = '';
    if (Object.keys(st).length) node.st = st;
    return node;
  }
  /* collapse wrappers that add nothing (no sig, no text, no style, single child) */
  function prune(n) {
    n.children = n.children.map(prune).filter(Boolean);
    var semantic = SEMANTIC.test(n.tag.toUpperCase());
    if (!n.sig.length && !n.text && !n.st && !n.img && !n.input && !semantic && n.children.length === 1) return n.children[0];
    if (!n.sig.length && !n.text && !n.st && !n.img && !n.input && !semantic && n.children.length === 0) return null;
    return n;
  }
  var tree = prune(walk(document.body, 0));
  var out = document.createElement('textarea');
  out.id = '__analysis';
  out.textContent = JSON.stringify({ tree: tree, images: images, height: document.documentElement.scrollHeight, width: innerWidth, title: document.title });
  document.body.appendChild(out);
})();
'''


def find_chrome():
    for p in ['/Applications/Google Chrome.app', os.path.expanduser('~/Applications/Google Chrome.app')]:
        if os.path.exists(p):
            return os.path.join(p, 'Contents/MacOS/Google Chrome')
    r = subprocess.run(['mdfind', "kMDItemCFBundleIdentifier == 'com.google.Chrome'"], capture_output=True, text=True)
    for line in r.stdout.splitlines():
        if line.endswith('.app'):
            return os.path.join(line, 'Contents/MacOS/Google Chrome')
    sys.exit('ERROR: Google Chrome not found')


def label(n):
    s = n['tag']
    if n['sig']:
        s += ' [' + ', '.join(dict.fromkeys(n['sig'])) + ']'
    return s


def fmt_style(st):
    if not st:
        return ''
    parts = []
    for k in ('bg', 'color', 'fs', 'fw', 'ff', 'border', 'borderBottom', 'radius', 'layout', 'gap', 'pad', 'pos', 'shadow'):
        if k in st and st[k] not in (None, ''):
            v = st[k]
            if k == 'pad':
                v = '/'.join(str(int(x)) for x in v)
            parts.append(f'{k}={v}')
    return ' {' + ' '.join(parts) + '}'


def to_md(n, depth, lines, max_depth):
    x, y, w, h = n['box']
    line = '  ' * depth + f'- {label(n)} @{x},{y} {w}×{h}' + fmt_style(n.get('st'))
    if n.get('text'):
        line += f' "{n["text"]}"'
    if n.get('input'):
        i = n['input']
        line += f' <input {i["type"]} value="{i["value"]}"' + (' checked' if i['checked'] else '') + '>'
    if n.get('img'):
        line += f' <img alt="{n.get("alt", "")}">'
    if n.get('svg'):
        line += ' <svg>'
    lines.append(line)
    if depth < max_depth:
        for c in n['children']:
            to_md(c, depth + 1, lines, max_depth)
    elif n['children']:
        lines.append('  ' * (depth + 1) + f'- … {len(n["children"])} more levels')


def find_sections(tree, page_w, page_h):
    """Page blocks small enough to read as one screenshot: split anything taller than 1200px."""
    out = []

    def add(n):
        x, y, w, h = n['box']
        if h < 16 or w < 40:
            return
        if (n.get('st') or {}).get('pos') == 'fixed':
            y = page_h - h if y > 200 else 0   # fixed bars render at the page edge in a full-page shot
        big_kids = [c for c in n['children'] if c['box'][3] >= 16]
        if (h > 1200 or n['tag'] == 'body') and big_kids:
            for c in big_kids:
                add(c)
            return
        out.append({'name': label(n), 'y': y, 'h': h, 'x': x, 'w': w, 'text': first_text(n),
                    'fixed': (n.get('st') or {}).get('pos') == 'fixed'})

    add(tree)
    return sorted(out, key=lambda s: s['y'])


def first_text(n):
    if n.get('text'):
        return n['text'][:80]
    for c in n['children']:
        t = first_text(c)
        if t:
            return t
    return ''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('snapshot')
    ap.add_argument('--out', required=True)
    ap.add_argument('--width', type=int, default=1440)
    ap.add_argument('--depth', type=int, default=40, help='max depth in outline.md')
    ap.add_argument('--no-images', action='store_true')
    a = ap.parse_args()

    out = os.path.abspath(a.out)
    os.makedirs(out, exist_ok=True)
    chrome = find_chrome()
    work = tempfile.mkdtemp(prefix='ving-analyze-')
    probe = os.path.join(work, 'probe.html')
    shutil.copy(a.snapshot, probe)
    with open(probe, 'a', encoding='utf-8') as f:
        f.write('<script>addEventListener("load",function(){var t=0;(function wait(){'
                'var pending=[].some.call(document.images,function(i){return !i.complete;});'
                'if(pending&&t++<80){setTimeout(wait,100);return;}' + PROBE_JS + '})();})</script>')
    common = [chrome, '--headless=new', '--disable-gpu', f'--user-data-dir={os.path.join(work, "p")}',
              '--hide-scrollbars', '--virtual-time-budget=12000']
    dom = subprocess.run(common + [f'--window-size={a.width},1000', '--dump-dom', 'file://' + probe],
                         capture_output=True, text=True, timeout=180).stdout
    m = re.search(r'<textarea id="__analysis">(.*?)</textarea>', dom, re.S)
    if not m:
        sys.exit('ERROR: analysis script produced no output')
    data = json.loads(html.unescape(m.group(1)))
    tree, height = data['tree'], data['height']

    with open(os.path.join(out, 'outline.json'), 'w', encoding='utf-8') as f:
        json.dump(tree, f, ensure_ascii=False)
    lines = [f'# Outline: {data["title"]}', f'Rendered at {a.width}px wide, page height {height}px. '
             'Format: tag [component names from class names] @x,y w×h {styles} "text"', '']
    to_md(tree, 0, lines, a.depth)
    with open(os.path.join(out, 'outline.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

    # full-page render, then per-section crops
    shot = os.path.join(out, 'page.png')
    subprocess.run(common + [f'--window-size={a.width},{min(height, 16000)}', f'--screenshot={shot}', 'file://' + os.path.abspath(a.snapshot)],
                   capture_output=True, timeout=180)
    sections = find_sections(tree, a.width, height)
    for i, s in enumerate(sections, 1):
        crop = os.path.join(out, f'section-{i:02d}.png')
        h = max(1, min(s['h'], height - s['y']))
        subprocess.run(['sips', '-c', str(h), str(a.width), '--cropOffset', str(max(0, s['y'])), '0', shot, '--out', crop], capture_output=True)
        subprocess.run(['sips', '-Z', '1600', crop], capture_output=True)
        s['png'] = os.path.basename(crop)
    with open(os.path.join(out, 'sections.json'), 'w', encoding='utf-8') as f:
        json.dump(sections, f, ensure_ascii=False, indent=1)

    # images
    imgs, seen = [], {}
    if not a.no_images:
        os.makedirs(os.path.join(out, 'images'), exist_ok=True)
        for im in data['images']:
            src = im['src']
            if src.startswith('data:image/svg') or src.endswith('.svg'):
                continue
            if src in seen:
                imgs.append({**seen[src], 'x': im['box'][0], 'y': im['box'][1], 'w': im['box'][2], 'h': im['box'][3], 'alt': im['alt'], 'dup': True})
                continue
            n = len(seen) + 1
            try:
                req = urllib.request.Request(src, headers={'User-Agent': UA, 'Accept': 'image/jpeg,image/png,image/webp,*/*;q=0.5'})
                with urllib.request.urlopen(req, timeout=30) as r:
                    body, ctype = r.read(), r.headers.get_content_type()
            except Exception as e:
                print(f'WARNING: image {src[:90]}… failed: {e}', file=sys.stderr)
                continue
            ext = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif'}.get(ctype, 'img')
            fn = f'img-{n:02d}.{ext}'
            path = os.path.join(out, 'images', fn)
            with open(path, 'wb') as f:
                f.write(body)
            if ext == 'avif':  # Figma upload doesn't take AVIF: convert to JPEG
                jpg = path[:-5] + '.jpg'
                if subprocess.run(['sips', '-s', 'format', 'jpeg', path, '--out', jpg], capture_output=True).returncode == 0:
                    os.remove(path)
                    fn = os.path.basename(jpg)
            rec = {'file': 'images/' + fn, 'src': src, 'content_type': 'image/jpeg' if fn.endswith('.jpg') else ctype}
            seen[src] = rec
            imgs.append({**rec, 'x': im['box'][0], 'y': im['box'][1], 'w': im['box'][2], 'h': im['box'][3], 'alt': im['alt']})
    with open(os.path.join(out, 'images.json'), 'w', encoding='utf-8') as f:
        json.dump(imgs, f, ensure_ascii=False, indent=1)

    print(json.dumps({'out': out, 'title': data['title'], 'width': a.width, 'height': height,
                      'outline_lines': len(lines), 'sections': [(s['png'], s['y'], s['h'], s['text'][:50]) for s in sections],
                      'unique_images': len(seen)}, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
