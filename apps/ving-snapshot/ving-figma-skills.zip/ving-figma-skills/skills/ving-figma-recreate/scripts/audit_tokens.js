// Token audit for a rebuilt page (read-only). Paste into use_figma, replacing FRAME_ID.
// Reports every property that carries a raw value instead of a Design Token variable,
// on nodes we built ourselves (instances are skipped: their internals belong to the library).
const root = await figma.getNodeByIdAsync("FRAME_ID");
const issues = [];
const isInsideInstance = n => { for (let p = n.parent; p; p = p.parent) if (p.type === 'INSTANCE') return true; return false; };
const bound = (n, prop) => n.boundVariables && n.boundVariables[prop];
const paintBound = (n, prop, i) => { const b = n.boundVariables && n.boundVariables[prop]; return Array.isArray(b) ? !!b[i] : false; };
for (const n of [root, ...root.findAll(() => true)]) {
  if (n.type === 'INSTANCE' || isInsideInstance(n)) continue;
  const where = n.name + ' (' + n.id + ')';
  if ('fills' in n && Array.isArray(n.fills)) n.fills.forEach((f, i) => {
    if (f.visible !== false && f.type === 'SOLID' && !(f.boundVariables && f.boundVariables.color)) issues.push(['fill', where]);
  });
  if ('strokes' in n && Array.isArray(n.strokes) && n.strokes.length) {
    n.strokes.forEach(s => { if (s.type === 'SOLID' && !(s.boundVariables && s.boundVariables.color)) issues.push(['stroke colour', where]); });
    for (const p of ['strokeWeight', 'strokeTopWeight', 'strokeBottomWeight', 'strokeLeftWeight', 'strokeRightWeight'])
      if (p in n && typeof n[p] === 'number' && n[p] > 0 && !bound(n, p) && !(p !== 'strokeWeight' && bound(n, 'strokeWeight'))) { issues.push([p, where]); break; }
  }
  if (n.type === 'FRAME' || n.type === 'COMPONENT') {
    if (n.layoutMode && n.layoutMode !== 'NONE') {
      if (n.itemSpacing > 0 && !bound(n, 'itemSpacing') && n.primaryAxisAlignItems !== 'SPACE_BETWEEN') issues.push(['gap ' + n.itemSpacing, where]);
      for (const p of ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft']) if (n[p] > 0 && !bound(n, p)) issues.push([p + ' ' + n[p], where]);
    }
    if (typeof n.cornerRadius === 'number' && n.cornerRadius > 0 && !bound(n, 'topLeftRadius') && !bound(n, 'cornerRadius')) issues.push(['radius ' + n.cornerRadius, where]);
  }
  if (n.type === 'TEXT') {
    const hasStyle = typeof n.textStyleId === 'string' && n.textStyleId;
    if (!hasStyle) {
      if (!bound(n, 'fontSize')) issues.push(['fontSize', where]);
      if (!bound(n, 'fontFamily')) issues.push(['fontFamily', where]);
    }
  }
}
const byType = {};
for (const [t] of issues) { const k = t.split(' ')[0]; byType[k] = (byType[k] || 0) + 1; }
return { total: issues.length, byType, first: issues.slice(0, 40) };
